The folder contains a mock squareRoot module

To run the test of mockSquareRoot type the command $ make mockRun. Know, however, that the real squartRoot unit tests require no dependancies, so one might as well just run those instead.
