CS4900 
2/15/2017
Greg Ostroy

Cunit macros and initializer

References
https://en.wikipedia.org/wiki/Machine_epsilon#How_to_determine_machine_epsilon
https://www.tutorialspoint.com/c_standard_library/float_h.htm
