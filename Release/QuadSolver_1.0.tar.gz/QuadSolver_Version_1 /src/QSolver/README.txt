CS4900 
2/15/2017
Greg Ostroy

This directory contains the function that computes the roots of a quadratic equation.
It also contains unit tests for the quad solver function.
The commnad to run the unit tests is '$ make runQuad'
