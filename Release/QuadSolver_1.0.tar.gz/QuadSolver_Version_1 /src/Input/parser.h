/*CS4900 
2/15/2017
Greg Ostroy

Declaration of parser

Copyright (C) 2017 Greg Ostroy see full notice in [installation path]/QuadraticSolver/doc/README
*/

/*This function takes 3 string arguments and parses floats from them.
parameters- The string from which to parse the floats, and the three float addresses to hold the floats
returns- 0 if three floats were parsed, 1 otherwise.
*/
int parseCoefficients(const char*,float*,float*,float*);
