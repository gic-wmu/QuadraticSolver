/*CS4900 
2/15/2017
Greg Ostroy

Declaration for the function that prints the roots found by a quadratic solver

Copyright (C) 2017 Greg Ostroy see full notice in [installation path]/QuadraticSolver/doc/README
*/

/*Prints the roots of a quadratic equation
parameters-pointers to two floats to recieve the root values
*/
void printRoots(float*, float*);
