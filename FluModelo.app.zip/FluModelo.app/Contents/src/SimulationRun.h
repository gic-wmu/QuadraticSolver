/*
 *  This file is part of Flu Modelo
 *
 *  Copyright (C) Western Michigan University

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

    authors-Greg Ostroy, Diana Prieto, Yuwen Gu
*/

/* A class that runs a simulation of a flu outbreak. It is intended to run in a thread parallel to other runs*/
#pragma once

#ifndef SIMULATIONRUN_H
#define SIMULATIONRUN_H

#include "City.h"
#include "mainwindow.h"
#include <vector>

class SimulationRun
{
	private:
        int _id;//a unique Id for the simulation run
		int _uniform_counter;//counter to iterate through _uniform[]
		long _seed;
		float _uniform[10001];//an array of uniformly distributed random numbers between 0 and 1
		int 	total_infected_pandemic ;
		int 	total_infected_seasonal ;
		int     total_sim_coinfected ;
		int 	total_infected_pandemic_only ;
		int 	total_infected_seasonal_only ;
		int 	total_coinfected_s_p;
		int 	total_reinfected_s_p ;
		int 	total_coinfected_p_s ;
		int 	total_reinfected_p_s ;
		int		total_infected; //total_infected_pandemic+total_infected_seasonal

		int	    new_infected_today_pandemic ; // number of new infected entities every day
		int	    new_infected_today_seasonal ; // number of new infected entities every day
		int	    new_infected_today_pandemic_only ; // number of new infected entities every day
		int	    new_infected_today_seasonal_only ; // number of new infected entities every day
		int	    new_sim_coinfected ; // number of new infected entities every day
		int	    new_coinfected_s_p ; // number of new infected entities every day
		int	    new_reinfected_s_p ; // number of new infected entities every day
		int	    new_coinfected_p_s ; // number of new infected entities every day
		int	    new_reinfected_p_s ; // number of new infected entities every day
		int	    new_recovered_today_pandemic ; // number of new recovered entities every day
		int	    new_recovered_today_seasonal ; // number of new recovered entities every day
		int		_totalPopulation;
		std::vector<class City*> _cities;
		std::vector<int> _infectedByDay_p;
		std::vector<int> _infectedByDay_s;
		std::vector<int> _totalInfectedByDay;
        MainWindow* _window;//pointer to the GUI window where output will be displayed
	public:
        SimulationRun(int, MainWindow*);
		~SimulationRun();
		int getId() const;
		City* getCity(int) const;
		float getUniformValue(int);
		void outbreak();
		bool hasCityWithOutbreak();
		int getDailyInfectedPandemic(int);
		int getDailyInfectedSeasonal(int);
		int getTotalInfected(int);
		double fluRandom();//random number generator from 0 to 1
		float uni(int,int);//random number generator from int a to int b
};
#endif
