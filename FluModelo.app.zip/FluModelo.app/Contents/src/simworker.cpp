/*
 *  This file is part of Flu Modelo
 *
 *  Copyright (C) Western Michigan University

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

    authors-Greg Ostroy, Diana Prieto, Yuwen Gu
*/

/*Implementation for the worker class. This class runs a flu simulation on a separate thread from the GUI window*/
#include"simworker.h"
#include "Flu_Manager.h"

SimWorker::SimWorker(MainWindow* window)
{
        _window=window;
}

SimWorker::~SimWorker()
{

}

void SimWorker::runSimulation()
{
    int runCount=0;//keep track of how many runs were completed
    //execute outbreak
    for(int i=0;i<Flu_Manager::Instance()->NUM_RUNS;i++)
    {
        if(_window->currentState !=MainWindow::RUNNING)//stop if process is halted or killed
           break;
        Flu_Manager::Instance()->getRun(i)->outbreak();\
        runCount++;
     }
    if(runCount>0)
    {
        //store global data
        FILE* globalOutput_genStats=fopen("output_general_stats.txt","w");
        fprintf(globalOutput_genStats, "Day		Infected_total		Infected_p		Infected_s\n");
         //collect global data
         for(int j=0;j<Flu_Manager::Instance()->max_days; j++)
        {
            _window->setDays(j+1,(double)j+1);
            int sumOfDaysPandemic=0;
            int sumOfDaysSeasonal=0;
            int sumOfDaysTotal=0;
            for(int i=0;i<runCount;i++)
            {
                if(j==0)
                {
                    sumOfDaysPandemic+=Flu_Manager::Instance()->getRun(i)->getDailyInfectedPandemic(j);
                    sumOfDaysSeasonal+=Flu_Manager::Instance()->getRun(i)->getDailyInfectedSeasonal(j);
                    sumOfDaysTotal+=Flu_Manager::Instance()->getRun(i)->getTotalInfected(j);
                }
                else
                {
                    sumOfDaysPandemic+=Flu_Manager::Instance()->getRun(i)->getDailyInfectedPandemic(j)-Flu_Manager::Instance()->getRun(i)->getDailyInfectedPandemic(j-1);
                    sumOfDaysSeasonal+=Flu_Manager::Instance()->getRun(i)->getDailyInfectedSeasonal(j)-Flu_Manager::Instance()->getRun(i)->getDailyInfectedSeasonal(j-1);
                    sumOfDaysTotal+=Flu_Manager::Instance()->getRun(i)->getTotalInfected(j)-Flu_Manager::Instance()->getRun(i)->getTotalInfected(j-1);
                }
            }
            int avePandemic=sumOfDaysPandemic/Flu_Manager::Instance()->NUM_RUNS;
            int aveSeasonal=sumOfDaysSeasonal/Flu_Manager::Instance()->NUM_RUNS;
            int aveTotal=sumOfDaysTotal/Flu_Manager::Instance()->NUM_RUNS;
            _window->setDailyPandemic(j+1,(double)avePandemic);
            _window->setDailySeasonal(j+1,(double)aveSeasonal);
            _window->setDailyTotal(j+1,(double)aveTotal);
            fprintf(globalOutput_genStats,"%d		%d			%d			%d\n",j+1,aveTotal,avePandemic,aveSeasonal);
        }
        fclose(globalOutput_genStats);
    }
    emit done(this);
}
