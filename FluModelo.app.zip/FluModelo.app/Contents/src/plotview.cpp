/*
 *  This file is part of Flu Modelo
 *
 *  Copyright (C) Western Michigan University

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

    authors-Greg Ostroy, Diana Prieto, Yuwen Gu
*/

#include "plotview.h"
#include "ui_plotview.h"
#include "qcustomplot.h"

PlotView::PlotView(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::PlotView)
{
    ui->setupUi(this);
}

PlotView::~PlotView()
{
    delete ui;
}

void PlotView::setPlot(QVector<LoadDialog::DataSet> data)
{
        int maxDays=0;
        //determine the longest dataset
        for(int i=0;i<data.size();i++)
        {
            if(data[i]._dataPoints.size()>maxDays)
                maxDays=data[i]._dataPoints.size();
        }
        //set each vector of data to match the longest set
        for(int i=0;i<data.size();i++)
        {
            if(data[i]._dataPoints.size()<maxDays)
                data[i]._dataPoints.insert(data[i]._dataPoints.size(),maxDays-data[i]._dataPoints.size(),0);//pad with zeros
        }
        //create a vector of days
        QVector<double> days;
        for(int i=1;i<=maxDays;i++)
            days.append((double)i);
        //set up plots
        ui->graph->clearGraphs();
        for(int i=0;i<data.size();i++)
        {
             //printf("%f\n",data[i]._dataPoints[50]);
             ui->graph->addGraph();
             ui->graph->graph(i)->setData(days,data[i]._dataPoints);
             ui->graph->graph(i)->setName(data[i].name);
             setColor(i);         
        }
        ui->graph->legend->setVisible(true);
        ui->graph->xAxis->setLabel("Day");
        ui->graph->yAxis->setLabel("Daily Number of Newly Infected");
        // set axes ranges
        ui->graph->rescaleAxes();
        ui->graph->replot();
}
//set the color of each plot
 void PlotView::setColor(int index)
 {
     Qt::GlobalColor color;
     switch(index)
     {
        case 0:
        {
            color=Qt::black;
            break;
        }
        case 1:
        {
             color=Qt::blue;
            break;
        }
        case 2:
        {
            color=Qt::red;
            break;
        }
        case 3:
        {
            color=Qt::darkGreen;
            break;
        }
        case 4:
        {
            color=Qt::gray;
            break;
        }
        case 5:
        {
            color=Qt::magenta;
            break;
        }
        case 6:
        {
            color=Qt::cyan;
            break;
        }
        case 7:
        {
            color=Qt::yellow;
            break;
        }
        default:
        {
            color=Qt::black;
            break;
        }
     }
     ui->graph->graph(index)->setPen(QPen(color));
 }
