/*
 *  This file is part of Flu Modelo
 *
 *  Copyright (C) Western Michigan University

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

    authors-Greg Ostroy, Diana Prieto, Yuwen Gu
*/

#include "Flu_Manager.h"
#include "Multi_City_44_Templates.h"
#include <QtConcurrent/QtConcurrent>
#include "savedialog.h"
#include "loaddialog.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->stackedWidget->setCurrentIndex(0);
    currentState=STOPPED;
    float rnNumber=1.1f;
    for(int i=0;i<10;i++)
    {
        float nextRN=rnNumber+(float)i/10;
        ui->RNdropdownPandemic->addItem(QString::number(nextRN));
        ui->RNdropdownSeasonal->addItem(QString::number(nextRN));
        ui->panRNchoice->addItem(QString::number(nextRN));
        ui->seasonalRNchoice->addItem(QString::number(nextRN));
    }
     ui->RNdropdownPandemic->setCurrentIndex(7);
     ui->panRNchoice->setCurrentIndex(7);
     ui->RNdropdownSeasonal->setCurrentIndex(2);
     ui->seasonalRNchoice->setCurrentIndex(2);
    //initializing default values for the flu suimulation
    Flu_Manager::Instance()->loadConstants();
    Flu_Manager::Instance()->loadInput();
    ui->plotDisplay->setVisible(false);
    ui->displayPlotMain->setVisible(false);
    ui->LocModPlot->setVisible(false);
    ui->none->setChecked(true);//set absenteeism to none as default
    ui->vacc->setEnabled(false);
    ui->AV->setEnabled(false);
    loadBaselineRef();
    _checkingLocModifiers=false;
    //cant save a plot until one is run
    ui->savePlots->setEnabled(false);
}

MainWindow::~MainWindow()
{
    delete Flu_Manager::Instance();
    delete ui;
}

void MainWindow::loadBaselineRef()
{
    _aveInfectedBase.push_back(0);
    FILE* baseline=fopen("PresetStatsUnscaledBase.txt","r");
    for(int i=0;i<125;i++)
    {
        int day,tot, pandemic,seasonal;
        fscanf(baseline,"%d",&day);
        fscanf(baseline,"%d",&tot);
        fscanf(baseline,"%d",&pandemic);
        fscanf(baseline,"%d",&seasonal);
        _aveInfectedBase.append((double)tot);
    }
    fclose(baseline);
}

void MainWindow::on_tutorialButton_clicked()
{
    ui->stackedWidget->setCurrentIndex(1);
}

void MainWindow::on_RNbuttom_clicked()
{
     ui->stackedWidget->setCurrentIndex(2);
}

void MainWindow::on_VaccinationStatus_clicked()
{
     ui->stackedWidget->setCurrentIndex(3);
}

void MainWindow::on_AbsButton_clicked()
{
     ui->stackedWidget->setCurrentIndex(5);
}

void MainWindow::on_AVbutton_clicked()
{
     ui->stackedWidget->setCurrentIndex(4);
}

void MainWindow::on_profileButton_clicked()
{
     ui->stackedWidget->setCurrentIndex(6);
}

void MainWindow::on_locModButton_clicked()
{
     ui->stackedWidget->setCurrentIndex(7);
}

void MainWindow::on_toMainTutorial_clicked()
{
    ui->stackedWidget->setCurrentIndex(1);
}

 void MainWindow:: on_MichiganOutbreak_clicked()
 {
    ui->stackedWidget->setCurrentIndex(8);
 }

 void MainWindow::on_references_clicked()
 {
    ui->stackedWidget->setCurrentIndex(9);
 }

void MainWindow::on_toMain_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);
}

void MainWindow::on_runSim_clicked()
{
    ui->stackedWidget->setCurrentIndex(10);
    //check number of days setting
    Flu_Manager::Instance()->max_days=ui->daysSlider->value();
    //check vaccination settings
    if(ui->pandemicVaccination->isChecked())
        Flu_Manager::Instance()->PANDEMIC_VACCINATION=1;
    else
        Flu_Manager::Instance()->PANDEMIC_VACCINATION=0;
    if(ui->seasonalVaccination->isChecked())
        Flu_Manager::Instance()->SEASONAL_VACCINATION=1;
    else
         Flu_Manager::Instance()->SEASONAL_VACCINATION=0;
    //check antiviral setting
    if(ui->AntiViralUse->isChecked())
         Flu_Manager::Instance()->usingAntivirals=1;
    else
        Flu_Manager::Instance()->usingAntivirals=0;
    //check voluntary quarantine settings
    if(ui->AbdsHosp->isChecked())
        Flu_Manager::Instance()->quarantineOption=Flu_Manager::QuarantineOptions::HOSPITALIZATION;
    else if(ui->abs->isChecked())
        Flu_Manager::Instance()->quarantineOption=Flu_Manager::QuarantineOptions::ABSENTEEISM;
    else
        Flu_Manager::Instance()->quarantineOption=Flu_Manager::QuarantineOptions::NONE;
    //check viral shedding settings
    if(ui->h3n2->isChecked())
        Flu_Manager::Instance()->currentStrain=Flu_Manager::VirusStrain::H3N2;
    else
        Flu_Manager::Instance()->currentStrain=Flu_Manager::VirusStrain::H1N1;
}

void MainWindow::on_daysSlider_valueChanged(int value)
{
    QString str=QString("Days: %1").arg(value);
    ui->numberDays->setText(str);
    Flu_Manager::Instance()->max_days=value;
}

void MainWindow::on_pandemicVaccination_toggled(bool checked)
{
    if(checked==true)
    {
        Flu_Manager::Instance()->PANDEMIC_VACCINATION=1;
        ui->vacc->setEnabled(true);
    }
    else
    {
        Flu_Manager::Instance()->PANDEMIC_VACCINATION=0;
        if(Flu_Manager::Instance()->SEASONAL_VACCINATION==0)
            ui->vacc->setEnabled(false);
    }
}

void MainWindow::on_seasonalVaccination_toggled(bool checked)
{
    if(checked==true)
    {
        Flu_Manager::Instance()->SEASONAL_VACCINATION=1;
        ui->vacc->setEnabled(true);
    }

    else
    {
         Flu_Manager::Instance()->SEASONAL_VACCINATION=0;
         if(Flu_Manager::Instance()->PANDEMIC_VACCINATION==0)
             ui->vacc->setEnabled(false);
    }

}

void MainWindow::on_AntiViralUse_toggled(bool checked)
{
    if(checked==true)
    {
         Flu_Manager::Instance()->usingAntivirals=1;
         ui->AV->setEnabled(true);
    }
    else
    {
        Flu_Manager::Instance()->usingAntivirals=0;
        ui->AV->setEnabled(false);
    }
}

void MainWindow::on_none_clicked()
{
    Flu_Manager::Instance()->quarantineOption=Flu_Manager::QuarantineOptions::NONE;
}

void MainWindow::on_abs_clicked()
{
    Flu_Manager::Instance()->quarantineOption=Flu_Manager::QuarantineOptions::ABSENTEEISM;
}

void MainWindow::on_AbdsHosp_clicked()
{
    Flu_Manager::Instance()->quarantineOption=Flu_Manager::QuarantineOptions::HOSPITALIZATION;
}

void MainWindow::on_h1n1_clicked()
{
    Flu_Manager::Instance()->currentStrain=Flu_Manager::VirusStrain::H1N1;
}

void MainWindow::on_h3n2_clicked()
{
     Flu_Manager::Instance()->currentStrain=Flu_Manager::VirusStrain::H3N2;
}

void MainWindow::on_numRuns_valueChanged(int arg1)
{
    int time =arg1*2;
    ui->estimationLabel->setText("Estimated time to complete runs: "+QString::number(time)+" minutes");
}

 void MainWindow::on_startLocSim_clicked()
 {
     if(currentState==STOPPED)
     {
         _checkingLocModifiers=true;
         _currentPlot=ui->LocModPlot;
         _currentStatusLabel=ui->locModRunStatus;
         _currentStartLabel=ui->locModButton;
         resetFluManager();
         float wpMod=(float)ui->workplaceMod ->value();
         float errMod=(float)ui->errandMod->value();
         Flu_Manager::Instance()->k_wp=wpMod/100;
         Flu_Manager::Instance()->k_er=errMod/100;
         _aveInfectedPandemic.clear();
         _aveInfectedSeasonal.clear();
         _aveInfectedTotal.clear();
         _days.clear();
         _aveInfectedPandemic.fill(0,Flu_Manager::Instance()->max_days+1);
         _aveInfectedSeasonal.fill(0,Flu_Manager::Instance()->max_days+1);
         _aveInfectedTotal.fill(0,Flu_Manager::Instance()->max_days+1);
         _days.fill(0,Flu_Manager::Instance()->max_days+1);
         ui->startLocSim->setText("Stop Simulation");
         ui->startSim->setEnabled(false);
         ui->RunSimulation->setEnabled(false);
         initSim();
     }
     else
     {
        currentState=STOPPED;
        _checkingLocModifiers=false;
        ui->startSim->setEnabled(true);
        ui->RunSimulation->setEnabled(true);
     }

 }
void MainWindow::on_RunSimulation_clicked()
{
    if(currentState==STOPPED)
    {
        _currentPlot=ui->displayPlotMain;
        _currentStatusLabel=ui->runStatus_2;
        _currentStartLabel=ui->RunSimulation;
        float rn=ui->panRNchoice->currentText().toFloat();
        float rn_seasonal=ui->seasonalRNchoice->currentText().toFloat();
        float wpMod=(float)ui->workplaceEntry->value();
        float errMod=(float)ui->errandEntry->value();
        Flu_Manager::Instance()->reproduction_number_pandemic=rn;
        Flu_Manager::Instance()->reproduction_number_seasonal=rn_seasonal;
        Flu_Manager::Instance()->k_wp=wpMod/100;
        Flu_Manager::Instance()->k_er=errMod/100;
        Flu_Manager::Instance()->SEED=(long)ui->seedValue->value();
        Flu_Manager::Instance()->NUM_RUNS=ui->numRuns->value();
        Flu_Manager::Instance()->SEVERITY=(float)ui->severityBaseValue->value();
        Flu_Manager::Instance()->AV_INFECTIOUSNESS=(float)ui->AVinfectiousnessValue->value();
        Flu_Manager::Instance()->AV_SYMPTOMATIC=(float)ui->AVseverityValue->value();
        Flu_Manager::Instance()->AV_TRANSMISSION=(float)ui->AVtransmissionValue->value();
        Flu_Manager::Instance()->VACCINE_COEFF_INFECTIOUSNESS=(float)ui->infectiousnessValue->value();
        Flu_Manager::Instance()->VACCINE_COEFF_SYMPTOMATIC=(float)ui->severityValue->value();
        Flu_Manager::Instance()->VACCINE_COEFF_TRANSMISSION=(float)ui->transmissionValue->value();
        _aveInfectedPandemic.clear();
        _aveInfectedSeasonal.clear();
        _aveInfectedTotal.clear();
        _days.clear();
        _aveInfectedPandemic.fill(0,Flu_Manager::Instance()->max_days+1);
        _aveInfectedSeasonal.fill(0,Flu_Manager::Instance()->max_days+1);
        _aveInfectedTotal.fill(0,Flu_Manager::Instance()->max_days+1);
        _days.fill(0,Flu_Manager::Instance()->max_days+1);
        ui->RunSimulation->setText("Stop Simulation");
        ui->startLocSim->setEnabled(false);
        ui->startSim->setEnabled(false);
        initSim();
    }
    else
    {
        currentState=STOPPED;
        ui->savePlots->setEnabled(true);
        ui->showPlots->setEnabled(true);
        ui->startLocSim->setEnabled(true);
        ui->startSim->setEnabled(true);
    }
}

void MainWindow::on_startSim_clicked()//run reproduction number sim
{
    if(currentState==STOPPED)
    {
        _currentPlot=ui->plotDisplay;
        _currentStatusLabel=ui->runStatus;
        _currentStartLabel=ui->startSim;
        resetFluManager();
        float rn=ui->RNdropdownPandemic->currentText().toFloat();
        float rn_seasonal=ui->RNdropdownSeasonal->currentText().toFloat();
        Flu_Manager::Instance()->reproduction_number_pandemic=rn;
        Flu_Manager::Instance()->reproduction_number_seasonal=rn_seasonal;
        _aveInfectedPandemic.clear();
        _aveInfectedSeasonal.clear();
        _aveInfectedTotal.clear();
        _days.clear();
        _aveInfectedPandemic.fill(0,Flu_Manager::Instance()->max_days+1);
        _aveInfectedSeasonal.fill(0,Flu_Manager::Instance()->max_days+1);
        _aveInfectedTotal.fill(0,Flu_Manager::Instance()->max_days+1);
        _days.fill(0,Flu_Manager::Instance()->max_days+1);
        ui->startSim->setText("Stop Simulation");
        ui->startLocSim->setEnabled(false);
        ui->RunSimulation->setEnabled(false);
        initSim();
    }
    else
    {
        currentState=STOPPED;
        ui->startLocSim->setEnabled(true);
        ui->RunSimulation->setEnabled(true);
    }
}

void MainWindow::initSim()
{
    //no saving or loading while simulation is running
    ui->savePlots->setEnabled(false);
    ui->showPlots->setEnabled(false);
    //initializes runs
    Flu_Manager::Instance()->clearRuns();
    for(int i=0;i<Flu_Manager::Instance()->NUM_RUNS;i++)
    {
        SimulationRun* run = new SimulationRun(i,this);
        Flu_Manager::Instance()->addRun(run);
    }
    currentState=RUNNING;
    Flu_Manager::Instance()->setKillFlag(false);
    SimWorker* worker=new SimWorker(this);
    QThread* thread =new QThread;
    worker->moveToThread(thread);
    connect(thread, SIGNAL(started()), worker,SLOT(runSimulation()));
    connect(worker,SIGNAL(done(SimWorker*)),thread,SLOT(quit()));
    //connect(worker,SIGNAL(done()),this,SLOT(deleteLater()));
    connect(worker,SIGNAL(done(SimWorker*)),this,SLOT(endSimulation(SimWorker*)));
    connect(thread, SIGNAL(finished()), thread, SLOT(deleteLater()));
    thread->start();
}

Ui::MainWindow * MainWindow::getUI() const
{
    return ui;
}

void MainWindow::endSimulation(SimWorker* worker)
{
    if(currentState !=STOPPED)
        _currentPlot->setVisible(true);
    else
        _currentPlot->setVisible(false);
    //create a plot
    _currentPlot->clearGraphs();
    _currentPlot->addGraph();
    _currentPlot->addGraph();
    if(_checkingLocModifiers== true)
    {
        _currentPlot->graph(0)->setData(_days,_aveInfectedBase );
        _currentPlot->graph(0)->setName("No Modifiers");
        _currentPlot->graph(1)->setData(_days, _aveInfectedTotal);
        _currentPlot->graph(1)->setName("Your Modifiers");
    }
    else
    {
        _currentPlot->graph(0)->setData(_days, _aveInfectedPandemic);
        _currentPlot->graph(0)->setName("Infected Virus 1");
        _currentPlot->graph(1)->setData(_days, _aveInfectedSeasonal);
        _currentPlot->graph(1)->setName("Infected Virus 2");
    }
    _currentPlot->graph(1)->setPen(QPen(Qt::red));
    _currentPlot->legend->setVisible(true);
    // give the axes some labels:
    _currentPlot->xAxis->setLabel("Day");
    _currentPlot->yAxis->setLabel("Daily Number of Newly Infected");
    // set axes ranges
    _currentPlot->rescaleAxes();
    _currentPlot->replot();
    _currentStartLabel->setText("Start Simulation");
    _currentStatusLabel->setText("Status:Not running");
    currentState=STOPPED;
    _checkingLocModifiers = false;
    //allow saving and loading again
    ui->savePlots->setEnabled(true);
    ui->showPlots->setEnabled(true);
    delete worker;
}
void MainWindow::updateStatus(QString str)
{
    _currentStatusLabel->setText(str);
}

QVector<double> MainWindow::getDailyPandemic()const
{
        return _aveInfectedPandemic;
}

QVector<double> MainWindow::getDailySeasonal()const
{
        return _aveInfectedSeasonal;
}

QVector<double> MainWindow::getDailyTotal()const
{
        return _aveInfectedTotal;
}

QVector<double> MainWindow::getDays()const
{
        return _days;
}

void MainWindow::setDailyPandemic(int index, double value)
{
     _aveInfectedPandemic[index]=value;
}

void MainWindow::setDailySeasonal(int index, double value)
{
    _aveInfectedSeasonal[index]=value;
}

void MainWindow::setDailyTotal(int index, double value)
{
    _aveInfectedTotal[index]=value;
}

void MainWindow::setDays(int index, double value)
{
    _days[index]=value;
}

void MainWindow::resetFluManager()
{
    Flu_Manager::Instance()->PANDEMIC_VACCINATION=0;
    Flu_Manager::Instance()->SEASONAL_VACCINATION=0;
    Flu_Manager::Instance()->usingAntivirals=0;
    Flu_Manager::Instance()->quarantineOption=Flu_Manager::QuarantineOptions::NONE;
    Flu_Manager::Instance()->max_days=125;
    Flu_Manager::Instance()->k_er=1.0f;
    Flu_Manager::Instance()->k_wp=1.0f;
    Flu_Manager::Instance()->SEED=46780615;
    Flu_Manager::Instance()->NUM_RUNS=1;
    Flu_Manager::Instance()->SEVERITY=.5f;
    Flu_Manager::Instance()->AV_INFECTIOUSNESS=.2f;
    Flu_Manager::Instance()->AV_SYMPTOMATIC=.4f;
    Flu_Manager::Instance()->AV_TRANSMISSION=.7f;
    Flu_Manager::Instance()->VACCINE_COEFF_INFECTIOUSNESS=.5f;
    Flu_Manager::Instance()->VACCINE_COEFF_SYMPTOMATIC=.17f;
    Flu_Manager::Instance()->VACCINE_COEFF_TRANSMISSION=.6f;
}
//load save methods
void MainWindow::on_savePlots_clicked()
{
    SaveDialog dialog(0,this);
    dialog.setModal(true);
    dialog.exec();
}

void MainWindow::on_showPlots_clicked()
{
    LoadDialog dialog;
    dialog.setModal(true);
    dialog.exec();
}

