/*
 *  This file is part of Flu Modelo
 *
 *  Copyright (C) Western Michigan University

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

    authors-Greg Ostroy, Diana Prieto, Yuwen Gu
*/

/*The SimWorker class executes a flu simulation in a separate thread from the GUI window*/
#pragma once

#ifndef SIMWORKER_H
#define SIMWORKER_H

#include <QObject>
#include "mainwindow.h"
#include "ui_mainwindow.h"

class SimWorker: public QObject
{
    Q_OBJECT
    public:
            SimWorker(class MainWindow *);
            ~SimWorker();
    signals:
            void done(SimWorker *);
    public slots:
            void runSimulation();
    private:
            class MainWindow * _window;
};
#endif // SIMWORKER_H


