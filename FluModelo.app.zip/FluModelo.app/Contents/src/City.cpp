/*
 *  This file is part of Flu Modelo
 *
 *  Copyright (C) Western Michigan University

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

    authors-Greg Ostroy, Diana Prieto, Yuwen Gu
*/

/*implimentation for the city class, uses algoritms developed by Diana Prieto -Greg Ostroy*/
#include <string>
#include <string.h>
#include <omp.h>
#include <iostream>
#include <fstream>
#include "City.h"
#include "Flu_Manager.h"

City::City(int id,bool outbreak,SimulationRun* sim)
{
	_id=id;
	p_run=sim;
	_population=0;
	new_sim_coinfected = 0;
	new_infected_today_pandemic = 0;
	new_infected_today_pandemic_only = 0;
	new_coinfected_s_p = 0;
	new_reinfected_s_p = 0;
	new_recovered_today_pandemic = 0;
	new_infected_today_seasonal = 0;
	new_infected_today_seasonal_only = 0;
	new_coinfected_p_s = 0;
	new_reinfected_p_s = 0;
	new_recovered_today_seasonal = 0;

	total_infected_pandemic=0;
	total_infected_seasonal=0;
	total_sim_coinfected=0;
	total_infected_pandemic_only=0;
	total_infected_seasonal_only=0;
	total_coinfected_s_p=0;
	total_reinfected_s_p=0;
	total_coinfected_p_s=0;
	total_reinfected_p_s=0;

	_probablityInfectedArrival_p=0.0f;
	_probablityInfectedArrival_s=0.0f;
	//set number of households according to region
	if(Flu_Manager::Instance()->SCALING==0)
	{
		NUM_HOUSEHOLDS=Flu_Manager::Instance()->getRegionUnscaledPopulation(id);
		_numOutsideArrivals=Flu_Manager::Instance()->getUnscaledOutsideArrivals(id);
	}
	else
	{
		NUM_HOUSEHOLDS=Flu_Manager::Instance()->getRegionScaledPopulation(id);
		_numOutsideArrivals=Flu_Manager::Instance()->getScaledOutsideArrivals(id);
	}
	//initialize arrays of repro numbers and generation sizes
	for(int i=0;i<Flu_Manager::Instance()->max_days;i++)
	{
		averages_rn_p.push_back(0.0f);
		averages_rn_s.push_back(0.0f);
		generationsPandemic.push_back(0);
		generationsSeasonal.push_back(0);
	}
	//get business data for this region
	std::string  filename;
	if(Flu_Manager::Instance()->SCALING==0)
		filename=Flu_Manager::Instance()->getUnscaledWorkFile(id);
	else
		filename=Flu_Manager::Instance()->getScaledWorkFile(id);
	std::ifstream workfile(filename); 
	if(workfile.is_open())
	{
		for (int i = 0; i <= number_business_type; ++i)
		{
			struct WorkPlaceTemplate work;
			workfile >> work._type >> work._numberOfType >> work._percentWork >> work._errandsWeekday >> work._errandsWeekend >> work._errandQuarantine >> work._numContacts >> work._cumBusinesses >> work._cumPerWork >> work._cumWeekday >> work._cumWeekend >> work._cumVoluntaryQuarantine;
			_workplaceTypes[i]=work;
		}
		workfile.close();
	}
	else
		std::cout<<"couldn't open file";
	//create a hospital in which to hold hosptalized people
	p_Hospital=new Location(0,0,0);
	//creates the cities people and businesses
	generateBusinesses();
	generateHousehold();
	assignWorkplaces();
	assignZipcodes();
	//set travel probabilities
	_probTravel=Flu_Manager::Instance()->getProbTravel(id);
	_probDestination = Flu_Manager::Instance()->getProbDestination(id);
	//start the outbreak if this city starts with infected
	if(outbreak==true)
	{
		_daysOutbreak=1;
		setPatientZeros();
	}	
	else
		_daysOutbreak=0;
	total_HH=0;
	total_WP=0;
	total_ER=0;
	total_infectedByZeros=0;
}


City::~City(void)
{
	//free household memory
	for(int i=0;i<NUM_HOUSEHOLDS;i++)//loop through the array of housholds and delete them
	{
		delete _households[i];
		_households[i]=nullptr;
	}
	_businesses.clear();
}

void City::updateOutbreak(int hour, int day)
{	
	disease_progress(hour);
	if(hour==1)
	{	//determine the number of out of state visitors for today
		if(Flu_Manager::Instance()->ALLOW_OOS_TRAVEL>0 )
			updateArrivals(day);
		setSchedule(day);
		if(Flu_Manager::Instance()->ALLOW_OOS_TRAVEL>0  && !_sickArrivals.empty())
		{
			//# pragma omp parallel for num_threads(Flu_Manager::Instance()->NUM_THREADS)
			for(int i=0;i<(int)_sickArrivals.size();i++)
				_sickArrivals[i]->setArrivalSchedule(day);
		}
	}
	if(hour<22 && hour>7)
	{
		declareLocations(hour);
		spreadDisease(hour,day);
	}
	total_household_people = 0;
	total_business_people = 0;

	for(int h=0;h < NUM_HOUSEHOLDS;h++)
		total_household_people+= _households[h]->getOccupants().size();
	fprintf(_output, "There are %d household people in the hour %d and day %d \n",total_household_people,hour,day);

	for(unsigned int b=1;b<_businesses.size();b++)
		total_business_people+=_businesses[b].getOccupants().size();
	fprintf(_output, "There are %d business people in the hour %d and day %d \n",total_business_people,hour,day);
	if (hour==24){
			//update probabilities of out of state arrivals being infected
			_probablityInfectedArrival_p=(float)new_infected_today_pandemic/_population;
			_probablityInfectedArrival_s=(float)new_infected_today_seasonal/_population;
			fprintf(_output_GeneralStats,"%d    %d		%d		%d		%d		%d		%d		%d		%d		%d		%d		%d		%d \n",_daysOutbreak,_population,total_infected_pandemic,new_recovered_today_pandemic,total_infected_seasonal,new_recovered_today_seasonal,total_infected_pandemic_only,total_infected_seasonal_only,total_coinfected_s_p,total_reinfected_s_p,total_coinfected_p_s,total_reinfected_p_s,total_sim_coinfected);
			//reset daily values
			new_sim_coinfected = 0;
			new_infected_today_pandemic = 0;
			new_infected_today_pandemic_only = 0;
			new_coinfected_s_p = 0;
			new_reinfected_s_p = 0;
			new_recovered_today_pandemic = 0;
			new_infected_today_seasonal = 0;
			new_infected_today_seasonal_only = 0;
			new_coinfected_p_s = 0;
			new_reinfected_p_s = 0;
			new_recovered_today_seasonal = 0;
			_daysOutbreak++;
	}
}
/*creates businesses based on an array of templates. For each template the 
appropriate number of businesses is created and initialized*/
void  City::generateBusinesses()
{
	int s=0;
	for (int i = 1; i <= number_business_type; ++i)//loop through business templates
	{//set prev values to zero for the first business created
		long double prevWork=0.0;//percentage of peolpe working in business n-1
		float prevWeekday=0.0f;//% errands run at business n-1 during week
		float prevWeekend=0.0f;//% errands run at business n-1 on the weekends
		float prevQuarantine=0.0f;// % volunatry quarantine errands run business n-1
		for (int k =s+1; k <=s+_workplaceTypes[i]._numberOfType; ++k) 
		{
			if(k>1)//after first business is created pevious values come from business n-1
			{
				prevWork=_businesses[k-2].getPerWorkplaces(); 
				prevWeekday=_businesses[k-2].getPerWeekdayErrands();
				prevWeekend =_businesses[k-2].getPerWeekendErrands();
				prevQuarantine=_businesses[k-2].getPerVolQuarantine();
			}
			//assign the above values for business n
			long double percentWorkplaces=prevWork+(long double)_workplaceTypes[i]._percentWork/_workplaceTypes[i]._numberOfType;
			float percentWeekdayErrands= prevWeekday+(float)_workplaceTypes[i]._errandsWeekday/_workplaceTypes[i]._numberOfType;
			float percentWeekendErrands= prevWeekend+(float)_workplaceTypes[i]._errandsWeekend/_workplaceTypes[i]._numberOfType;
			float percentVoluntaryQuarantine= prevQuarantine+(float)_workplaceTypes[i]._errandQuarantine/_workplaceTypes[i]._numberOfType;;
			//assign business contact rate
			int contactRate=_workplaceTypes[i]._numContacts;
			//create business and add to the businesses array
			Business bus(i,k,percentWorkplaces,percentWeekdayErrands,percentWeekendErrands,percentVoluntaryQuarantine,contactRate);
			_businesses.push_back(bus);
		}
		s+=_workplaceTypes[i]._numberOfType;//advance to the next group of businesses
	}
}
/*create the cities households and people number of adults and children are based 
on a random sampling of an array of husehold templates*/
void  City::generateHousehold()
{
	int n1=0; int n2=0;
    //# pragma omp parallel for num_threads(Flu_Manager::Instance()->NUM_THREADS)
	for (int i=0;i<NUM_HOUSEHOLDS;++i)
	{
		float y = p_run->uni(0,1); // n1 = #adults, n2 = # kids, randomly genereated
		for (int s=1;s<=number_household_type;++s) {
				if (y>= Flu_Manager::Instance()->getHouseCumPmf(s-1) && y < Flu_Manager::Instance()->getHouseCumPmf(s)) {
					n1=  Flu_Manager::Instance()->getHouseNumAdults(s);
					n2=  Flu_Manager::Instance()->getHouseNumChildren(s);
				}
			}
	#pragma omp critical
		_population+=n1+n2;//add the people to the total population
		//create the household, the household will create its own people
		Household* household=new Household(n1,n2,this);
	#pragma omp critical
		_households.push_back(household);//add it to the array of households
	}
	# pragma omp parallel for num_threads(Flu_Manager::Instance()->NUM_THREADS) 
	for (int i=0;i<NUM_HOUSEHOLDS;++i)
		_households[i]->setFamiliyPtrs();//people reference their household
}
/*assign each household a zipcode*/
void  City::assignZipcodes()
{ 
	int total_per_zipcode;
	int householdCtr=0;
	for (int i = 1; i <= number_zipcodes; ++i)
	{
		total_per_zipcode=(int)(Flu_Manager::Instance()->getZipCumProb(i) *_population);
		int j=0;
		//assign households to zip code until total per zip code is reached or all households are assigned
		while(j< total_per_zipcode && householdCtr<NUM_HOUSEHOLDS)
		{
			int size=_households[householdCtr]->getSize();
			if(total_per_zipcode-j<size)//let a house with more people than zip spaces left be assigned to the next zipcode
				break;
			_households[householdCtr]->setZipCode(Flu_Manager::Instance()->getZipcode(i));
			j+=size;//j increases by size of household
			householdCtr++;//advance to the next household
		}
	}
	while(householdCtr<NUM_HOUSEHOLDS)//assign any remaining households the last zipcode
	{
		_households[householdCtr]->setZipCode(Flu_Manager::Instance()->getZipcode(number_zipcodes));
		householdCtr++;//advance to the next household
	}
}
/*have each household assign workplaces to it's members*/
void  City::assignWorkplaces()
{
    //# pragma omp parallel for num_threads(Flu_Manager::Instance()->NUM_THREADS)
	for(int i=0;i<NUM_HOUSEHOLDS;i++)
	{
			_households[i]->assignWorkplaces(_businesses);
	}
}

SimulationRun* City::getSimRun() const
{
	return p_run;
}

Household* City::getHousehold(int index) const
{
	return _households[index];
}

int City::getPopulationSize() const
{
	return _population;
}

int City::getBusinessSize() const
{
	return _businesses.size();
}

int City::getId() const
{
	return _id;
}

Business * City::getBusiness(int index)
{
	Business * bPtr=&_businesses[index];
	return bPtr;
}

Location* City::getHospital() const
{
	return p_Hospital;
}

float City::getPandemicRn(int index) const
{
	return averages_rn_p[index];
}

float City::getSeasonalRn(int index) const
{
	return averages_rn_s[index];
}

int City::getPandemicGenerations(int index) const
{
	return generationsPandemic[index];
}

int City::getSeasonalGenerations(int index) const
{
	return generationsSeasonal[index];
}

float City::getProbTravel() const
{
	return _probTravel;
}

float City::getProbDestination() const
{
	return _probDestination;
}

int City::getDaysOutbreak() const
{
	return _daysOutbreak;
}

int City::getNumHouseholds()const
{
	return NUM_HOUSEHOLDS;
}

int City::getBusinessNumbers(int index) const
{
	return _workplaceTypes[index]._numberOfType;
}

void City::addToInfectedList(Person* person)
{
	_infected.insert(std::pair<int,Person*>(person->getId(),person));
}

void City::remmoveFromInfectedList(int id)
{
	if(_infected.count(id)>0)
		_infected.erase(id);
}
//chooses random households which choose a random person to start out as infected
void City::setPatientZeros()
{	//loop from 0 to n-1 where n is the initial number of infected people set by a config file
	for(int i=0;i<Flu_Manager::Instance()->initial_infected_pandemic;i++)
	{	//choose a random household
		int infected=(int)p_run->uni(0,NUM_HOUSEHOLDS);
		_households[infected]->pickPatientZero(true);//household chooses a person among its members	
	}
	//repeat for seasonal virus
	for(int i=0;i<Flu_Manager::Instance()->initial_infected_seasonal;i++)
	{
		int infected=(int)p_run->uni(0,NUM_HOUSEHOLDS);
		_households[infected]->pickPatientZero(false);
	}
}
/*gathers the number of people infected this hour and calls functions to update the hours and days each infected person has been 
sick */
void City::disease_progress(int hour)
{
	//# pragma omp parallel for num_threads(Flu_Manager::Instance()->NUM_THREADS) 
	for(int i=0;i<NUM_HOUSEHOLDS;i++)
	{		//loop through households
			for(int j=0; j<_households[i]->getNumAdults();j++)
			{	//gather and record the number of newly infected people
				new_recovered_today_pandemic+= _households[i]->getAdult(j)->setDiseaseClockPandemic(hour);//updates each persons infection clock in the household
				new_recovered_today_seasonal+= _households[i]->getAdult(j)->setDiseaseClockSeasonal(hour);
			}
			for(int j=0; j<_households[i]->getNumChildren();j++)
			{   //same as for adults
				new_recovered_today_pandemic+= _households[i]->getChild(j)->setDiseaseClockPandemic(hour);
				new_recovered_today_seasonal+= _households[i]->getChild(j)->setDiseaseClockSeasonal(hour);
			}
	}	
}
/*sets each persons daily schedule. Takes the day to be scheduled as an argument*/
void City::setSchedule(int day)
{	//loop through each household
    //# pragma omp parallel for num_threads(Flu_Manager::Instance()->NUM_THREADS)
	for(int i=0;i<NUM_HOUSEHOLDS;i++)
	{
		for(int j=0; j<_households[i]->getNumAdults();j++)
		{	//schedule adults day
			_households[i]->getAdult(j)->setSchedule(day);	
		}
		for(int j=0; j<_households[i]->getNumChildren();j++)
		{
			//schedule childs day
			_households[i]->getChild(j)->setSchedule(day);	
		}
	}
}
//put peoples ids into the array of occupants at their location at hour
void City::declareLocations(int hour)
{	//clear last hour's business location data
    //# pragma omp parallel for num_threads(Flu_Manager::Instance()->NUM_THREADS)
	for( int bus=0;bus< (int)_businesses.size();bus++)
	{
			_businesses[bus].setNumInfected(0);
			_businesses[bus].removeOccupants();
	}
	for(int i=0;i<NUM_HOUSEHOLDS;i++)
	{//clear last hour's household location data
		_households[i]->setNumInfected(0);
		_households[i]->removeOccupants();
		for( int j=0; j<_households[i]->getNumAdults();j++)	
			_households[i]->getAdult(j)->declareLocation(hour);	//declare adult locations
		for(int j=0; j<_households[i]->getNumChildren();j++)	
			_households[i]->getChild(j)->declareLocation(hour);//declare child locations
	}
	if(Flu_Manager::Instance()->ALLOW_TRAVEL>0  && !_sickArrivals.empty())
		{
			//# pragma omp parallel for num_threads(Flu_Manager::Instance()->NUM_THREADS)
			for(int i=0;i<(int)_sickArrivals.size();i++)
				_sickArrivals[i]->declareLocation(hour);
		}
}

void City::spreadDisease(int hour,int day)
{
	for(std::map<int,Person*>::iterator it=_infected.begin();it != _infected.end();it++)
	{
		it->second->processInfections(hour,day);
	}
	if(Flu_Manager::Instance()->ALLOW_TRAVEL>0 &&!_sickArrivals.empty())
	{
			for(unsigned int i=0;i<_sickArrivals.size();i++)
				_sickArrivals[i]->processInfections(hour,day);
	}
}

void City::addInfected(Person* person)
{
	addToInfectedList(person);
	switch(person->infectionType)
	{
		case INFECTED_PANDEMIC:
		{
			new_infected_today_pandemic_only++;
			new_infected_today_pandemic++;
			total_infected_pandemic++;
			total_infected_pandemic_only++;
			break;
		}
		case INFECTED_SEASONAL:
		{
			new_infected_today_seasonal_only++;
			new_infected_today_seasonal++;
			total_infected_seasonal++;
			total_infected_seasonal_only++;
			break;
		}
		case COINFECTED_PANDEMIC_SEASONAL:
		{
			new_coinfected_p_s++;
			new_infected_today_seasonal++;
			total_infected_seasonal++;
			total_coinfected_p_s++;
			break;
		}
		case COINFECTED_SEASONAL_PANDEMIC:
		{
			new_coinfected_s_p++;
			new_infected_today_pandemic++;
			total_infected_pandemic++;
			total_coinfected_s_p++;
			break;
		}
		case REINFECTED_PANDEMIC_SEASONAL:
		{
			new_reinfected_p_s ++;
			new_infected_today_seasonal++;
			total_infected_seasonal++;
			total_reinfected_p_s++;
			break;
		}
		case REINFECTED_SEASONAL_PANDEMIC:
		{
			new_reinfected_s_p ++;
			new_infected_today_pandemic++;
			total_infected_pandemic++;
			total_reinfected_s_p++;
			break;
		}
		case  COINFECTED_SIMULTANEOUS:
		{
			new_sim_coinfected++;
			new_infected_today_pandemic++;
			new_infected_today_seasonal++;
			total_infected_pandemic++;
			total_infected_seasonal++;
			total_sim_coinfected++;
			break;
		}
	}
}

int City::getInfectedByType(int infectionType)
{
	switch(infectionType)
	{
		case INFECTED_PANDEMIC:
			return total_infected_pandemic_only;
		case INFECTED_SEASONAL:
			return total_infected_seasonal_only;
		case COINFECTED_PANDEMIC_SEASONAL:
			return total_coinfected_p_s;
		case COINFECTED_SEASONAL_PANDEMIC:
			return total_coinfected_s_p;
		case REINFECTED_PANDEMIC_SEASONAL:
			return total_reinfected_p_s;
		case REINFECTED_SEASONAL_PANDEMIC:
			return total_reinfected_s_p;
		case  COINFECTED_SIMULTANEOUS:
			return total_sim_coinfected;
		default:
			return 0;
	}
}

int City::getNewInfectedByType(int infectionType)
{
	switch(infectionType)
	{
		case INFECTED_PANDEMIC:
			return new_infected_today_pandemic_only;
		case INFECTED_SEASONAL:
			return new_infected_today_seasonal_only;
		case COINFECTED_PANDEMIC_SEASONAL:
			return new_coinfected_p_s;
		case COINFECTED_SEASONAL_PANDEMIC:
			return new_coinfected_s_p;
		case REINFECTED_PANDEMIC_SEASONAL:
			return new_reinfected_p_s;
		case REINFECTED_SEASONAL_PANDEMIC:
			return new_reinfected_s_p;
		case  COINFECTED_SIMULTANEOUS:
			return new_sim_coinfected;
		default:
			return 0;
	}
}

int City::getNewRecoverd(bool pandemic)
{
	if(pandemic==true)
		return new_recovered_today_pandemic;
	return new_recovered_today_seasonal;
}
//make a textfiles for storing output data and open them	
void City::openOutputFiles()	
{
	//make a city id string
	char runId[4];
	sprintf(runId,"%d",p_run->getId());
	char idStr[4];//a string representation of the cities id
	sprintf(idStr,"%d",_id);//convert id to string
	std::string rId="Run_";
	std::string cityId="_City_no";
	rId += runId+cityId+idStr;
	//make an output file for daily general stats
	char outputGenStats_cStr[42];
	strcpy(outputGenStats_cStr,rId.c_str());
	char dailyStats_cStr[21]="_dailyStatistics.txt";
	strcat(outputGenStats_cStr,dailyStats_cStr);
	//open the textflie for output
	_output_GeneralStats=fopen(outputGenStats_cStr,"w");
	_output=fopen("locationCheck.txt","w");
	//print general stats header
	fprintf(_output_GeneralStats, "Day  Population  Infected_p  Recovered_p  Infected_s  Recovered_s  Infected_p_only  Infected_s_only coinfected_s_p reinfected_s_p coinfected_p_s reinfected_p_s coinfected_sim\n");
	//checkContacts=fopen("checkContacts.txt","w");
}

void City::closeOutputFiles()
{
	fclose(_output);
	fclose(_output_GeneralStats);
	//fclose(checkContacts);
}

void City::checkRNumber()
{
	//make a city id string
	char runId[4];
	sprintf(runId,"%d",p_run->getId());
	char idStr[4];//a string representation of the cities id
	sprintf(idStr,"%d",_id);//convert id to string
	std::string rId="Run_";
	std::string cityId="_City_no";
	rId += runId+cityId+idStr;

	char output_cStr[36];//a c-string to hold the file name
	//make an output file for hourly locations of people
	strcpy(output_cStr,rId.c_str());
	char R_cStr[14]="_R_Output.txt";//append name of specific file to city's id string
	strcat(output_cStr,R_cStr);
	//open file and print header
	FILE* output_R = fopen(output_cStr,"w");
	fprintf(output_R, "Generation   Generation_size_p   Avg_R_p   Generation_size_s   Avg_R_s\n");
	//create a single list of all the city's people
	std::vector<Person*> people;//an array of pointers to all the people in the city
	for(int h=0;h<NUM_HOUSEHOLDS;h++)//fill the people array
	{
		for(int p=0;p<_households[h]->getNumAdults();p++)
			people.push_back(_households[h]->getAdult(p));
		for(int p=0;p<_households[h]->getNumChildren();p++)
			people.push_back(_households[h]->getChild(p));
	}
	//use that list of people to check reproduction numbers over time
	for(int aux=1; aux <= Flu_Manager::Instance()->max_days; ++ aux)
	{
		int aux_size_p = 0;
		int aux_sumrn_p = 0;
		int aux_size_s = 0;
		int aux_sumrn_s = 0;
		float aux_average_rn_p= 0.0f;
		float aux_average_rn_s= 0.0f;

		for(unsigned int p=0;p<people.size();p++)
		{
			if(people[p]->getGenerationPandemic()==aux){
				++aux_size_p;
				aux_sumrn_p = aux_sumrn_p + people[p]->getReproNumber(true);	
			}
			if(people[p]->getGenerationSeasonal()==aux){
				++aux_size_s;
				aux_sumrn_s = aux_sumrn_s + people[p]->getReproNumber(false);	
			}
		}
		//get the average repro numbers
		if(aux_size_p >0)//don't divide by zero
			aux_average_rn_p=  (float)aux_sumrn_p/aux_size_p;
		if(aux_size_s >0)//don't divide by zero	
			aux_average_rn_s=  (float)aux_sumrn_s/aux_size_s;
		//store values for retrieval 
		generationsPandemic[aux-1]=aux_size_p;
		generationsSeasonal[aux-1]=aux_size_s;
		averages_rn_p[aux-1]=aux_average_rn_p;
		averages_rn_s[aux-1]=aux_average_rn_s;
		fprintf(output_R,"	%d			%d			%f			%d			%f \n", aux, aux_size_p, aux_average_rn_p, aux_size_s, aux_average_rn_s);
	}
	fclose(output_R);
}

bool City::outbreakRunning()
{
	if(_daysOutbreak > 0 && _daysOutbreak <=Flu_Manager::Instance()->max_days)
		return true;
	return false;
}

void City::startOutbreak()
{
	_daysOutbreak=1;//start the clock for this city
}
//determines the number of sick arrivals from out of state for this day
void City::updateArrivals(int day)
{
	_sickArrivals.clear();//remove previous days arrivals
	bool infectedPandemic=false;
	bool infectedSeasonal=false;
	//determine how many arrivals will be sick 
	for(int i=0; i < _numOutsideArrivals;i++)
	{
		float diceRoll=p_run->uni(0,1);
		if(diceRoll<=_probablityInfectedArrival_p)
			infectedPandemic=true;
		diceRoll=p_run->uni(0,1);
		if(diceRoll<=_probablityInfectedArrival_s)
			infectedSeasonal=true;
		if(infectedPandemic==true || infectedSeasonal==true)//person is infected add them to a list of infected arrivals
		{
			int age=21;
			//set the age, I will assume all ravelers are adults
			float y=p_run->uni(0,1);//the random value
			if (y <= Flu_Manager::Instance()->getAdultAgesCumProb(1)) {//person is 22-29
				age = (int)p_run->uni(22, Flu_Manager::Instance()->getAdultAge(1));
			}
			else if (y >Flu_Manager::Instance()->getAdultAgesCumProb(1)&& y <= Flu_Manager::Instance()->getAdultAgesCumProb(2)) {//person is 29-64
				age= (int)p_run->uni( Flu_Manager::Instance()->getAdultAge(1), Flu_Manager::Instance()->getAdultAge(2));
			}
			else {//person is over 64
				age = (int)p_run->uni( Flu_Manager::Instance()->getAdultAge(2), Flu_Manager::Instance()->getAdultAge(3));
			}
			Person* person= new Person(age,this); //set city to this one, actual city of origin doesn't matter
			person->pickRestingPlace();//find a place for them to stay
			//infect the person
			if(infectedPandemic==true)
				person->infected(true,nullptr,day);//treat as 1st generation infected (infector==null)
			if(infectedSeasonal==true)
				person->infected(false,nullptr,day);
			person->setTraveling(true);
			_sickArrivals.push_back(person);
		}
		infectedPandemic=false;
		infectedSeasonal=false;
	}
}
