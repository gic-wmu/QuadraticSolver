/*
 *  This file is part of Flu Modelo
 *
 *  Copyright (C) Western Michigan University

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

    authors-Greg Ostroy, Diana Prieto, Yuwen Gu
*/

#include "savedialog.h"
#include "ui_savedialog.h"
#include "Flu_Manager.h"
#include <QDateTime>
#include <QFileDialog>

SaveDialog::SaveDialog(QWidget *parent,MainWindow* win) :
    QDialog(parent),_window(win),
    ui(new Ui::SaveDialog)
{
    ui->setupUi(this);
}

SaveDialog::~SaveDialog()
{
    delete ui;
}

void SaveDialog::on_saveButton_2_clicked()
{
    QString defaultStr=setDefaultString(1);
    saveResult(defaultStr,1);

}

void SaveDialog::on_saveButton_1_clicked()
{
    QString defaultStr=setDefaultString(0);
    saveResult(defaultStr,0);
}

void SaveDialog::on_saveButton_3_clicked()
{
    QString defaultStr=setDefaultString(2);
    saveResult(defaultStr,2);
}

void SaveDialog::saveResult(QString defaultName, int saveWhat)
{
   QFileDialog saveDialog(this);
   saveDialog.setDefaultSuffix("data");
   QString fileName = saveDialog.getSaveFileName(this, "Save Result", "savedResults/"+defaultName, tr("*.data;;*All Files"));
   if (fileName.isEmpty())
       return;
   else
   {
       QFile file(fileName);
       if (!file.open(QIODevice::WriteOnly))
       {
          QMessageBox::information(this, tr("Unable to open file"),
          file.errorString());
          return;
       }
       QDataStream out(&file);
       out.setVersion(QDataStream::Qt_5_6);
       switch(saveWhat)
       {
        case 0:
        {
           out << _window->getDailyPandemic();
           break;
       }
        case 1:
        {
           out << _window->getDailySeasonal();
           break;
        }
        case 2:
        {
           out << _window->getDailyTotal();
           break;
        }
       }
       file.close();
    }
}
//create a unique default filename for each file saved
QString SaveDialog::setDefaultString(int index)
{
    QString defaultString="Virus_";
    switch(index)
    {
        case 0:
        {
            defaultString.append("1_");
            break;
        }
        case 1:
        {
            defaultString.append("2_");
            break;
        }
        case 2:
        {
            defaultString.append("Total_");
            break;
        }
        default:
            break;
    }
    if(Flu_Manager::Instance()->currentStrain==Flu_Manager::VirusStrain::H3N2)
        defaultString.append("H3N2_");
    else
        defaultString.append("H1N1_");
    QDateTime time=QDateTime::currentDateTime();
    defaultString.append( time.toString(Qt::TextDate));//makes the name unique
    defaultString.replace(":","_",Qt::CaseSensitive);//replace colons, they cannot be in a file name
    return defaultString;
}
