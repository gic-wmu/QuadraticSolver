/*
 *  This file is part of Flu Modelo
 *
 *  Copyright (C) Western Michigan University

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

    authors-Greg Ostroy, Diana Prieto, Yuwen Gu
*/

#include "loaddialog.h"
#include "ui_loaddialog.h"
#include "plotview.h"
#include <QFileDialog>
#include <QMessageBox>

LoadDialog::LoadDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::LoadDialog)
{
    ui->setupUi(this);
    addLabels();
    addBoxes();
    addButtons();
    addLineEdit();
    initDataSets();
}

LoadDialog::~LoadDialog()
{
    delete ui;
}

void LoadDialog::initDataSets()
{
    for(int i=0; i<8; i++)
    {
        struct DataSet set;
        set.name=_plotNames[i]->text();
        set.active=false;
        _dataSets[i]=set;
    }
}

void LoadDialog::addLabels()
{
    _fileNames[0]=ui->fileLabel;
    _fileNames[1]=ui->fileLabel_2;
    _fileNames[2]=ui->fileLabel_3;
    _fileNames[3]=ui->fileLabel_4;
    _fileNames[4]=ui->fileLabel_5;
    _fileNames[5]=ui->fileLabel_6;
    _fileNames[6]=ui->fileLabel_7;
    _fileNames[7]=ui->fileLabel_8;
}
void LoadDialog::addBoxes()
{
    _useFiles[0]=ui->Result_2;
    _useFiles[1]=ui->Result_3;
    _useFiles[2]=ui->Result_4;
    _useFiles[3]=ui->Result_5;
    _useFiles[4]=ui->Result_6;
    _useFiles[5]=ui->Result_7;
    _useFiles[6]=ui->Result_8;
}

void LoadDialog::addButtons()
{
    _loadButtons[0]=ui->chooseButton;
    _loadButtons[1]=ui->chooseButton_2;
    _loadButtons[2]=ui->chooseButton_3;
    _loadButtons[3]=ui->chooseButton_4;
    _loadButtons[4]=ui->chooseButton_5;
    _loadButtons[5]=ui->chooseButton_6;
    _loadButtons[6]=ui->chooseButton_7;
    _loadButtons[7]=ui->chooseButton_8;
}

void LoadDialog::addLineEdit()
{
    _plotNames[0]=ui->plotName;
    _plotNames[1]=ui->plotName_2;
    _plotNames[2]=ui->plotName_3;
    _plotNames[3]=ui->plotName_4;
    _plotNames[4]=ui->plotName_5;
    _plotNames[5]=ui->plotName_6;
    _plotNames[6]=ui->plotName_7;
    _plotNames[7]=ui->plotName_8;
}

void LoadDialog::on_loadButtonBox_accepted()
{

}

void LoadDialog::on_loadButtonBox_rejected()
{

}

void LoadDialog::on_Result_2_toggled(bool checked)
{
    if(checked==true)
    {
        _loadButtons[1]->setEnabled(true);
        _fileNames[1]->setEnabled(true);
        ui->labelPlot_2->setEnabled(true);
        ui->plotName_2->setEnabled(true);
        _useFiles[1]->setEnabled(true);
        if(!_dataSets[1]._dataPoints.isEmpty())//enable if dataSet contains data
            _dataSets[1].active=true;
    }
    else
    {
        _loadButtons[1]->setEnabled(false);
        _fileNames[1]->setEnabled(false);
        ui->labelPlot_2->setEnabled(false);
        ui->plotName_2->setEnabled(false);
        _dataSets[1].active=false;
    }
}

void LoadDialog::on_Result_3_toggled(bool checked)
{
    if(checked==true)
    {
        _loadButtons[2]->setEnabled(true);
        _fileNames[2]->setEnabled(true);
        ui->labelPlot_3->setEnabled(true);
        ui->plotName_3->setEnabled(true);
        _useFiles[2]->setEnabled(true);
        if(!_dataSets[2]._dataPoints.isEmpty())//enable if dataSet contains data
            _dataSets[2].active=true;
    }
    else
    {
        _loadButtons[2]->setEnabled(false);
        _fileNames[2]->setEnabled(false);
        ui->labelPlot_3->setEnabled(false);
        ui->plotName_3->setEnabled(false);
        _dataSets[2].active=false;
    }
}

void LoadDialog::on_Result_4_toggled(bool checked)
{
    if(checked==true)
    {
        _loadButtons[3]->setEnabled(true);
        _fileNames[3]->setEnabled(true);
        ui->labelPlot_4->setEnabled(true);
        ui->plotName_4->setEnabled(true);
        _useFiles[3]->setEnabled(true);
        if(!_dataSets[3]._dataPoints.isEmpty())//enable if dataSet contains data
            _dataSets[3].active=true;
    }
    else
    {
        _loadButtons[3]->setEnabled(false);
        _fileNames[3]->setEnabled(false);
        ui->labelPlot_4->setEnabled(false);
        ui->plotName_4->setEnabled(false);
        _dataSets[3].active=false;
    }
}

void LoadDialog::on_Result_5_toggled(bool checked)
{
    if(checked==true)
    {
        _loadButtons[4]->setEnabled(true);
        _fileNames[4]->setEnabled(true);
        ui->labelPlot_5->setEnabled(true);
        ui->plotName_5->setEnabled(true);
        _useFiles[4]->setEnabled(true);
        if(!_dataSets[4]._dataPoints.isEmpty())//enable if dataSet contains data
            _dataSets[4].active=true;
    }
    else
    {
        _loadButtons[4]->setEnabled(false);
        _fileNames[4]->setEnabled(false);
        ui->labelPlot_5->setEnabled(false);
        ui->plotName_5->setEnabled(false);
        _dataSets[4].active=false;
    }
}

void LoadDialog::on_Result_6_toggled(bool checked)
{
    if(checked==true)
    {
        _loadButtons[5]->setEnabled(true);
        _fileNames[5]->setEnabled(true);
        ui->labelPlot_6->setEnabled(true);
        ui->plotName_6->setEnabled(true);
        _useFiles[5]->setEnabled(true);
        if(!_dataSets[5]._dataPoints.isEmpty())//enable if dataSet contains data
            _dataSets[5].active=true;
    }
    else
    {
        _loadButtons[5]->setEnabled(false);
        _fileNames[5]->setEnabled(false);
        ui->labelPlot_6->setEnabled(false);
        ui->plotName_6->setEnabled(false);
        _dataSets[5].active=false;
    }
}

void LoadDialog::on_Result_7_toggled(bool checked)
{
    if(checked==true)
    {
        _loadButtons[6]->setEnabled(true);
        _fileNames[6]->setEnabled(true);
        ui->labelPlot_7->setEnabled(true);
        ui->plotName_7->setEnabled(true);
        _useFiles[6]->setEnabled(true);
        if(!_dataSets[6]._dataPoints.isEmpty())//enable if dataSet contains data
            _dataSets[6].active=true;
    }
    else
    {
        _loadButtons[6]->setEnabled(false);
        _fileNames[6]->setEnabled(false);
        ui->labelPlot_7->setEnabled(false);
        ui->plotName_7->setEnabled(false);
        _dataSets[6].active=false;
    }
}

void LoadDialog::on_Result_8_toggled(bool checked)
{
    if(checked==true)
    {
        _loadButtons[7]->setEnabled(true);
        _fileNames[7]->setEnabled(true);
        ui->labelPlot_8->setEnabled(true);
        ui->plotName_8->setEnabled(true);
        if(!_dataSets[7]._dataPoints.isEmpty())//enable if dataSet contains data
            _dataSets[7].active=true;
    }
    else
    {
        _loadButtons[7]->setEnabled(false);
        _fileNames[7]->setEnabled(false);
        ui->labelPlot_8->setEnabled(false);
        ui->plotName_8->setEnabled(false);
        _dataSets[7].active=false;
    }
}

void LoadDialog::on_chooseButton_clicked()
{
    addPlot(0);
}

void LoadDialog::on_chooseButton_2_clicked()
{
    addPlot(1);
}

void LoadDialog::on_chooseButton_3_clicked()
{
    addPlot(2);
}

void LoadDialog::on_chooseButton_4_clicked()
{
    addPlot(3);
}

void LoadDialog::on_chooseButton_5_clicked()
{
   addPlot(4);
}

void LoadDialog::on_chooseButton_6_clicked()
{
    addPlot(5);
}

void LoadDialog::on_chooseButton_7_clicked()
{
    addPlot(6);
}

void LoadDialog::on_chooseButton_8_clicked()
{
    addPlot(7);
}

void LoadDialog::addPlot(int index)
{
    QFileDialog loadDialog(this);
    QString fileName=loadDialog.getOpenFileName(this,"Load Data From File","savedResults/",tr("*.data;;*All Files"));

    if (fileName.isEmpty())
        return;
    else
    {
        QString abbrFile=parseString(fileName);//get just the file without its path to diplay in the window
        _fileNames[index]->setText(abbrFile);
        QFile file(fileName);
        if (!file.open(QIODevice::ReadOnly))
        {
             QMessageBox::information(this, tr("Unable to open file"),
                       file.errorString());
                   return;
        }
        QDataStream in(&file);
        in.setVersion(QDataStream::Qt_5_6);
        in >>_dataSets[index]._dataPoints;
        if(_dataSets[index]._dataPoints.isEmpty())
        {
             QMessageBox::information(this, tr("No data in file"),tr("The file you are attempting to open contains no data."));
             return;
        }
        _dataSets[index].active=true;
        //for(int i=0;i<_dataSets[index]._dataPoints.size();i++)
           // printf("%f\n",_dataSets[index]._dataPoints[i]);
    }
}

void LoadDialog::on_plotName_editingFinished()
{
    _dataSets[0].name=ui->plotName->text();
}

void LoadDialog::on_plotName_2_editingFinished()
{
    _dataSets[1].name=_plotNames[1]->text();
}

void LoadDialog::on_plotName_3_editingFinished()
{
    _dataSets[2].name=_plotNames[2]->text();
}

void LoadDialog::on_plotName_4_editingFinished()
{
    _dataSets[3].name=_plotNames[3]->text();
}

void LoadDialog::on_plotName_5_editingFinished()
{
    _dataSets[4].name=_plotNames[4]->text();
}

void LoadDialog::on_plotName_6_editingFinished()
{
    _dataSets[5].name=_plotNames[5]->text();
}

void LoadDialog::on_plotName_7_editingFinished()
{
    _dataSets[6].name=_plotNames[6]->text();
}

void LoadDialog::on_plotName_8_editingFinished()
{
    _dataSets[7].name=_plotNames[7]->text();
}

void LoadDialog::on_drawButton_clicked()
{
    QVector<DataSet> usedData;
    //check that there is data to display
    for(int i=0;i<8;i++)
    {
        if(_dataSets[i].active==true)
        {
            _dataSets[i].name=_plotNames[i]->text();
            usedData.append(_dataSets[i]);
        }
    }
    if(!usedData.isEmpty())
    {
        PlotView view;
        view.setModal(true);
        view.setPlot(usedData);
        view.exec();
    }
}
//takes a string with a full path file name and returns the filename without the path
QString LoadDialog::parseString(QString fullPath)
{
    int slashCount=fullPath.count('/');
    QString justFile=fullPath.section('/',slashCount,slashCount);
    return justFile;
}
