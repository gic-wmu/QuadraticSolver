/*
 *  This file is part of Flu Modelo
 *
 *  Copyright (C) Western Michigan University

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

    authors-Greg Ostroy, Diana Prieto, Yuwen Gu
*/

#pragma once

#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "simworker.h"
#include "qcustomplot.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
    enum RunState{RUNNING,STOPPED};//the possible running states of the Simulation process
    enum RunType{REPRO_NUMBER,VACCINATION,ABSENTEEISM,ALL};//REPRO_NUMBER=run adusting reproduction numbers only,VACCINATION=run adusting vaccination use only,ABSENTEEISM=run adusting absenteeism/hospitalization only,ALL=run with all parameters adjustable
    RunState currentState;//the current running states of the Simulationn process

    void runSimulation();
    void updateStatus(QString);
    QVector<double> getDailyPandemic() const;
    QVector<double> getDailySeasonal() const;
    QVector<double> getDailyTotal() const;
    QVector<double> getBaselineRef() const;
    QVector<double> getDays() const;
    void setDailyPandemic(int, double);
    void setDailySeasonal(int, double);
    void setDailyTotal(int, double);
    void setDays(int, double);
    void loadBaselineRef();
    void initSim();
    //void setLargestY(int);//sets the largest y value on graphs of simulation output
public slots:
    void on_tutorialButton_clicked();

    void on_RNbuttom_clicked();

    void on_VaccinationStatus_clicked();

    void on_AbsButton_clicked();

    void on_AVbutton_clicked();

    void on_profileButton_clicked();

    void on_toMainTutorial_clicked();

    void on_toMain_clicked();

    void on_startSim_clicked();

    void on_MichiganOutbreak_clicked();

    void on_locModButton_clicked();

    void on_references_clicked();

    void on_runSim_clicked();

    void endSimulation(class SimWorker*);

    void on_daysSlider_valueChanged(int value);

    void on_pandemicVaccination_toggled(bool checked);

    void on_seasonalVaccination_toggled(bool checked);

    void on_AntiViralUse_toggled(bool checked);

    void on_RunSimulation_clicked();

    void on_none_clicked();

    void on_abs_clicked();

    void on_AbdsHosp_clicked();

    void on_h1n1_clicked();

    void on_h3n2_clicked();

    Ui::MainWindow* getUI()const;

private slots:


    void on_startLocSim_clicked();

    void on_savePlots_clicked();

    void on_showPlots_clicked();

    void on_numRuns_valueChanged(int arg1);

private:
    Ui::MainWindow *ui;
    QString _str;
    QVector<double> _aveInfectedPandemic;//array of average pandemic infected per day from multiple runs for plotting
    QVector<double> _aveInfectedSeasonal;//array of average seasonal infected per day from multiple runs for plotting
    QVector<double> _aveInfectedTotal;//array of average total infected per day from multiple runs for plotting
    QVector<double> _aveInfectedBase;//array of baseline infected for comparisons
    QVector<double> _days;//array of days for plotting
    QCustomPlot *_currentPlot;//the plot display to use in the GUI
    QLabel *_currentStatusLabel;//the label to display the status of a running simulation
    QPushButton *_currentStartLabel;//the current start button
    void resetFluManager();
    void iniSim();
    bool _checkingLocModifiers;//is the simulation for just locationModifiers going to run;
};

#endif // MAINWINDOW_H
