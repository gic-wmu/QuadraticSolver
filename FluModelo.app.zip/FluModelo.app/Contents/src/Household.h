/*
 *  This file is part of Flu Modelo
 *
 *  Copyright (C) Western Michigan University

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

    authors-Greg Ostroy, Diana Prieto, Yuwen Gu
*/

#pragma once
#include <vector>
#include "Location.h"
#include "Person.h"

#ifndef HOUSEHOLD_H
#define HOUSEHOLD_H
class Household :
	public Location
{
private:
	std::vector<class Person*> _adults;
	std::vector<class Person*> _children;
	class SimulationRun* p_run;
	class City* p_city;
	int _zipcode;
public:
	Household(int,int, class City*);
	~Household(void);
	void addAdult(class City*);
	void addChild(class City*);
	void setZipCode(int);
	int getSize() const;
	int getNumAdults() const;
	int getNumChildren() const;
	int getZipcode() const;
	Person* getAdult(int) const;
	Person* getChild(int) const;
	void assignWorkplaces(std::vector<class Business> &);
	void setFamiliyPtrs();
	void pickPatientZero(bool);
};
#endif

