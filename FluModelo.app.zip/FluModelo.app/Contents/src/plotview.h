/*
 *  This file is part of Flu Modelo
 *
 *  Copyright (C) Western Michigan University

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

    authors-Greg Ostroy, Diana Prieto, Yuwen Gu
*/

#ifndef PLOTVIEW_H
#define PLOTVIEW_H

#include <QDialog>
#include "loaddialog.h"

namespace Ui {
class PlotView;
}

class PlotView : public QDialog
{
    Q_OBJECT

public:
    explicit PlotView(QWidget *parent = 0);
    ~PlotView();
    void setPlot(QVector<LoadDialog::DataSet>);

private:
    Ui::PlotView *ui;
    void setColor(int);
};

#endif // PLOTVIEW_H
