/*
 *  This file is part of Flu Modelo
 *
 *  Copyright (C) Western Michigan University

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

    authors-Greg Ostroy, Diana Prieto, Yuwen Gu
*/

#ifndef LOADDIALOG_H
#define LOADDIALOG_H

#include <QDialog>
#include  <QLabel>
#include <QCheckbox>
#include <QPushButton>
#include <QLineEdit>

namespace Ui {
class LoadDialog;
}

class LoadDialog : public QDialog
{
    Q_OBJECT

public:
    explicit LoadDialog(QWidget *parent = 0);
    ~LoadDialog();
    struct DataSet
    {
        QString name;
        QVector<double> _dataPoints;
        bool active;
    };
private slots:
    void on_loadButtonBox_accepted();

    void on_loadButtonBox_rejected();

    void on_Result_2_toggled(bool checked);

    void on_Result_3_toggled(bool checked);

    void on_Result_4_toggled(bool checked);

    void on_Result_5_toggled(bool checked);

    void on_Result_6_toggled(bool checked);

    void on_Result_7_toggled(bool checked);

    void on_chooseButton_clicked();

    void on_chooseButton_2_clicked();

    void on_chooseButton_3_clicked();

    void on_chooseButton_4_clicked();

    void on_chooseButton_5_clicked();

    void on_chooseButton_6_clicked();

    void on_chooseButton_7_clicked();

    void on_chooseButton_8_clicked();

    void on_Result_8_toggled(bool checked);

    void on_plotName_editingFinished();

    void on_plotName_2_editingFinished();

    void on_plotName_3_editingFinished();

    void on_plotName_4_editingFinished();

    void on_plotName_5_editingFinished();

    void on_plotName_6_editingFinished();

    void on_plotName_7_editingFinished();

    void on_plotName_8_editingFinished();

    void on_drawButton_clicked();

private:
    Ui::LoadDialog *ui;
    QLabel* _fileNames[8];
    QCheckBox* _useFiles[7];
    QPushButton* _loadButtons[8];
    QLineEdit* _plotNames[8];
    void addLabels();
    void addBoxes();
    void addButtons();
    void addLineEdit();
    void addPlot(int);
    struct DataSet _dataSets[8];
    void initDataSets();
    QString parseString(QString);
};

#endif // LOADDIALOG_H
