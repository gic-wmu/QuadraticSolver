/*
 *  This file is part of Flu Modelo
 *
 *  Copyright (C) Western Michigan University

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

    authors-Greg Ostroy, Diana Prieto, Yuwen Gu
*/

/*Implemetation of the Person class */
#include<set>
#include<math.h>
#include "Person.h"
#include "Multi_City_44_Templates.h"
#include "Flu_Manager.h"

#define WEEKDAY 0
#define WEEKEND 1
#define UNEMPLOYED 2


using namespace std;

int Person::_idCounter=0;//first person created will have id 0

Person::Person(int age,City* city)
{
	_id=_idCounter;//increments with each person created
	_idCounter++;
	_day_begin_infection_pandemic=0; 
	_day_begin_infection_seasonal=0; 
	_disease_clock_pandemic=0;
	_disease_clock_seasonal=0;
	_daysOfPandemicInfection=-6;//all people start out alive and well
	_daysOfSeasonalInfection=-6;
	_rn_init_pandemic=0.0f;
	_rn_init_seasonal=0.0f;
	_rn_pandemic=0;
	_rn_seasonal=0;
	_generation_pandemic=0;
    _generation_seasonal=0;
	_contactCounterWP=0;
	_contactCounterER=0;
	_contactCounterHH=0;
	_age=age;
	p_city=city;
	p_visitingCity=city;
	currentVirusType=NONE;
	prevVirusType=NONE;
	profilePandemic=UNDEFINED;
	profileSeasonal=UNDEFINED;
	symptomatic=NOT_INFECTED;
	quaratineState=NO_QUARANTINE;//no one starts out too sick to work
	_traveling=false;
	_maxTravelDays=0;
	_daysTraveled=0;
	//populate the errand arrays with Errand Structs
	for(int i=0;i<3;i++)
	{
		struct Errand uErrand; //weekday errands for the unemployed
		uErrand._errandHour=8;
		uErrand._businessId=1;
		uErrand._numContacts=0;
		_errandsUnemployed[i]=uErrand;
		struct Errand wErrand;//weekend errands
		wErrand._errandHour=10;
		wErrand._businessId=1;
		wErrand._numContacts=0;
		_errandsWeekend[i]=wErrand;
	}
	setVaccinationStatus();
	setAntiviralStatus();
}


Person::~Person(void)
{
}

void Person::setWorkplace(Business* work)
{	
	p_workplace=work;
}

void Person::setVaccinationStatus()
{
	if(Flu_Manager::Instance()->PANDEMIC_VACCINATION==1 || Flu_Manager::Instance()->SEASONAL_VACCINATION==1)
	{
		//assign % coverage based on age
		float vaccineCoverage;//% of people that have been vaccinated for pandemic flu
		if(_age<=5)
			vaccineCoverage= Flu_Manager::Instance()->VACC_COVERAGE_0TO5;
		else if(_age>5 && _age<=14)
			vaccineCoverage= Flu_Manager::Instance()->VACC_COVERAGE_6TO14;
		else if(_age>14 && _age<=17)
			vaccineCoverage= Flu_Manager::Instance()->VACC_COVERAGE_15TO17;
		else if(_age>17 && _age<=29)
			vaccineCoverage= Flu_Manager::Instance()->VACC_COVERAGE_18TO29;
		else if(_age>29 && _age<=64)
			vaccineCoverage= Flu_Manager::Instance()->VACC_COVERAGE_30TO64;
		else //person is 64+ years old
			vaccineCoverage = Flu_Manager::Instance()->VACC_COVERAGE_65PLUS;
		if(Flu_Manager::Instance()->PANDEMIC_VACCINATION==1)//Pandemic vaccinations being used in simulation
		{  
			float diceRoll=p_city->getSimRun()->uni(0,1);//%chance that person has been vaccinated for pandemic flu
			if(diceRoll<=vaccineCoverage)
				_vaccinated_pandemic=true;
			else
				_vaccinated_pandemic=false;
		}
		else
			_vaccinated_pandemic=false;
		if(Flu_Manager::Instance()->SEASONAL_VACCINATION==1)//Seasonal vaccinations being used in simulation
		{
			float diceRoll=p_city->getSimRun()->uni(0,1);//%chance that person has been vaccinated for seasonal flu
			if(diceRoll<=vaccineCoverage)
				_vaccinated_seasonal=true;
			else
				_vaccinated_seasonal=false;
		}
		else
			_vaccinated_seasonal=false;
	}
	else //vaccination is not being used in simulation
	{
		_vaccinated_pandemic=false;
		_vaccinated_seasonal=false;
	}	
}

void Person::setAntiviralStatus()
{
	if(Flu_Manager::Instance()->usingAntivirals==1)
	{
		if(_age<=5 || _age>=65)//antivirals will be given only to the most vulnerable people
		{
			float diceRoll=p_city->getSimRun()->uni(0,1);
			if(diceRoll <= Flu_Manager::Instance()->ANTIVIRAL_PROB)
				_onAntivirals=true;
			else
				_onAntivirals=false;
		}
		else
			_onAntivirals=false;
	}
	else
		_onAntivirals=false;
}

void Person::setHousehold(Household* home)
{
	p_home= home;
	p_home->addOccupant(this);//homes start out occupied at hour 1;
	p_restPlace=home;//home is the persons defaul resting place
}

int Person::getAge() const
{
	return _age;
}

Household* Person::getHousehold() const
{
	return p_home;
}

int Person::getId() const
{
	return _id;
}

City* Person::getCity() const
{
	return p_city;
}

void Person::setCity(City* city)
{
	p_city=city;
}

Location* Person::getLocation(int hr) const
{
	return _schedule[hr];
}

int Person::getGenerationPandemic() const
{
	return _generation_pandemic;
}
int Person::getGenerationSeasonal() const
{
	return _generation_seasonal;
}
//switch persons current location
void Person::setLocation(int hr,Location* newLoc)
{
	_schedule[hr]=newLoc;
}

void Person::setReproNumber(bool pandemic)
{
	if(pandemic==true)
		_rn_pandemic++;
	else
		_rn_seasonal++;

}

int Person::getReproNumber(bool pandemic) const
{
	if(pandemic==true)
		return _rn_pandemic;
	return _rn_seasonal;
}

bool Person::getVaccinationStatusPandemic()const
{
	return _vaccinated_pandemic;
}

bool Person::getVaccinationStatusSeasonal()const
{
	return _vaccinated_seasonal;
}

bool Person::getAntiviralStatus()const
{
	return _onAntivirals;
}
//determines if the person will be absent from work due to illness
Person::eQuarantineType Person::isAbsent()
{
	float prob;
	if(_daysOfPandemicInfection<=0 && _daysOfSeasonalInfection<=0)
		return NO_QUARANTINE;//person is not infected or has not had the virus long enough to show symptoms
	float randNum = p_city->getSimRun()->uni(0,1);
	if(_daysOfPandemicInfection>0)// check pandemic virus
	{
			prob = Flu_Manager::Instance()->getGamma1CumDensity(_daysOfPandemicInfection) * Flu_Manager::Instance()->SEVERITY;
			if(randNum <= prob)
				return checkHospitalized();//person will either stay home or go to the hospital
	}
	if(_daysOfSeasonalInfection>0)//check seasonal virus
	{
			prob = Flu_Manager::Instance()->getGamma1CumDensity(_daysOfSeasonalInfection)  * Flu_Manager::Instance()->SEVERITY;
			if(randNum <= prob)
				return checkHospitalized();
	}
	return NO_QUARANTINE;//person feels well enough to work
}
//Determine if a person too ill too work will be hospitalized or just stay home
Person::eQuarantineType Person::checkHospitalized()
{	
	if(Flu_Manager::Instance()->quarantineOption==Flu_Manager::Instance()->HOSPITALIZATION)//hospitalization option is being used
	{
		float prob=0.0f;//percent chance that a person will be hospitalized
		if(_age<=5 ||(_age>29 &&_age<64))
			prob=.001f;// unit is %
		else if(_age>5 && _age<=29)
			prob=.000429f;
		else //person is 64+ years old
			prob=.005f;
		prob/=100;//normalize percentage
		float diceRoll=p_city->getSimRun()->uni(0,1);
		if(diceRoll<=prob)
			return HOSPITALIZED;//person will be hospitalized
		return AT_HOME;//person will stay home
	}
	return AT_HOME;//No hosptalization option, everyone too sick to work just stays home
}
/*when a person is first infected this function sets the appropriate parameters. Takes a boolean argument;
true if the infecting virus is pandemic, false if it's seasonal*/
void Person::infected(bool pandemic,Person* infector,int day)
{
	if(pandemic==true)
	{	
		//contactee has pandemic virus
		if(infector==nullptr)//initial infected
			_generation_pandemic=1;
		else //infected contactee is one level down from infector on the tree
		{	
			_generation_pandemic=infector->getGenerationPandemic()+1;
			infector->setReproNumber(true);
		}
		_day_begin_infection_pandemic=day;
		_disease_clock_pandemic=0;	
		_daysOfPandemicInfection = -2;//set to "just infected"
		if(prevVirusType==NONE)
		{
			_rn_init_pandemic= Flu_Manager::Instance()->reproduction_number_pandemic;
			currentVirusType=PANDEMIC;
			prevVirusType=PANDEMIC;
			infectionType=INFECTED_PANDEMIC;
		}
		else if(prevVirusType==SEASONAL)
		{
			if(_disease_clock_seasonal==-3) // recovered from seasonal
			{
				_rn_init_pandemic= Flu_Manager::Instance()->reproduction_number_pandemic*Flu_Manager::Instance()->epsilon_pr;
				currentVirusType=PANDEMIC;
				prevVirusType=BOTH;//person was already picked for seasonal, now he/she has both
				infectionType=REINFECTED_SEASONAL_PANDEMIC;
			}
				
			else//person is now nfected with both viruses
			{
				_rn_init_pandemic= Flu_Manager::Instance()->reproduction_number_pandemic*Flu_Manager::Instance()->epsilon_p;
				currentVirusType=BOTH;
				prevVirusType=BOTH;//person was already picked for seasonal, now he/she has both
				if(_day_begin_infection_seasonal==day)//person has simultaneously been infected with pandemic and seasonal virus
					infectionType=COINFECTED_SIMULTANEOUS;
				else//infections were not simultaneous
					infectionType=COINFECTED_SEASONAL_PANDEMIC;
			}		
		}
		//printf("person with pandemic virus is %d with disease clock %d \n",_id, _disease_clock_pandemic);
	}
	else //contactee has seasonal virus
	{
		if(infector==nullptr)//initial infected
			_generation_seasonal=1;
		else
		{
			_generation_seasonal=infector->getGenerationSeasonal()+1; //infected is one level down from infector on the tree
			infector->setReproNumber(false);
		}
		_day_begin_infection_seasonal=day;
		_disease_clock_seasonal=0;
		_daysOfSeasonalInfection = -2;
		if(prevVirusType==NONE)
		{
			_rn_init_seasonal= Flu_Manager::Instance()->reproduction_number_seasonal;
			currentVirusType=SEASONAL;
			prevVirusType=SEASONAL;
			infectionType=INFECTED_SEASONAL;
		}	
		else if(prevVirusType==PANDEMIC)
		{
				if(_disease_clock_pandemic==-3)
				{
					_rn_init_seasonal= Flu_Manager::Instance()->reproduction_number_seasonal*Flu_Manager::Instance()->epsilon_sr;
					currentVirusType=SEASONAL;
					prevVirusType=BOTH;
					infectionType=REINFECTED_PANDEMIC_SEASONAL;
				}	
				else
				{
					_rn_init_seasonal= Flu_Manager::Instance()->reproduction_number_seasonal*Flu_Manager::Instance()->epsilon_s;
					currentVirusType=BOTH;
					prevVirusType=BOTH;
					if(_day_begin_infection_pandemic==day)//person has simultaneously been infected with pandemic and seasonal virus
						infectionType=COINFECTED_SIMULTANEOUS;
					else
						infectionType=COINFECTED_PANDEMIC_SEASONAL;
				}		
		}
		//printf("person with seasonal virus is %d with disease clock %d \n",_id, _disease_clock_pandemic);
	}
	profile_assignment(currentVirusType);//set symptom profile
}
/*update the number of days a sick person has been infected, or set them as recovered if the period of infection
is over. Takes the hour of the day as an argument. Returns 1 if person is recovered 0 otherwise*/
int Person::setDiseaseClockPandemic(int hour)
{
	int recovered=0;
	if(_disease_clock_pandemic>=0 && _disease_clock_pandemic< culmination_period)//the person is not in recovery
	{  
		if(_daysOfPandemicInfection>0 || (_daysOfPandemicInfection==-2 && hour==8)) //the person has an ongoing infection
		{
			_disease_clock_pandemic++;
			_daysOfPandemicInfection = (_disease_clock_pandemic/(24+1))+1;
		}
	}
	else if(_disease_clock_pandemic >= culmination_period) //the period of infection is over, the person is marked as recovered
	{
		_disease_clock_pandemic=-3;
		_daysOfPandemicInfection=-5;
		if(currentVirusType==BOTH)
			currentVirusType=SEASONAL;
		else
		{
			currentVirusType=NONE;
			p_city->remmoveFromInfectedList(_id);
		}
		recovered=1;
	}
	return recovered;//added to city's list of number of newly recovered this day
}
/*same as setDiseaseClockPandemic, but for seasonal virus*/
int Person::setDiseaseClockSeasonal(int hour)
{
	int recovered=0;
	if(_disease_clock_seasonal>=0 && _disease_clock_seasonal< culmination_period)
	{
		if(_daysOfSeasonalInfection>0 || (_daysOfSeasonalInfection==-2 && hour==8))
			{
				_disease_clock_seasonal++;
				_daysOfSeasonalInfection = (_disease_clock_seasonal/(24+1))+1;
			}
	}
	else if(_disease_clock_seasonal >= culmination_period)
	{
		_disease_clock_seasonal=-3;
		_daysOfSeasonalInfection=-5;
		if(currentVirusType==BOTH)
			currentVirusType=PANDEMIC;
		else
		{
			currentVirusType=NONE;
			p_city->remmoveFromInfectedList(_id);
		}
		recovered=1;
	}
	return recovered;
}
/*set a persons daily schedule.Takes as arguments the day to be scheduled and a reference to the array of businesses
in the city. 
_outSick is false by default and will only change when the Absenteeism option is set to on(1)*/
void Person::setSchedule(int day)
{
	if(Flu_Manager::Instance()->quarantineOption!=Flu_Manager::Instance()->NONE)//A quarantine option is being used, check if person will be out sick or in the hosptial
		quaratineState=isAbsent();
	if((Flu_Manager::Instance()->ALLOW_TRAVEL>0 ||Flu_Manager::Instance()->ALLOW_OOS_TRAVEL>0) && quaratineState==NO_QUARANTINE)
	{
		//check who is travelling
		if((_daysOfPandemicInfection>=0 && _daysOfPandemicInfection<10) ||( _daysOfSeasonalInfection>=0 &&  _daysOfSeasonalInfection < 10) || _traveling==true)
			setTravelState();
	}
	if(quaratineState==HOSPITALIZED)//put person in hospital
	{
		for(int i=1;i<=24;i++)
			_schedule[i-1]=p_city->getHospital();
	}
	else if (p_restPlace == p_Outside || quaratineState==AT_HOME)//person is out of state schedule him to the out of state location all day
	{
		for(int i=1;i<=24;i++)
			_schedule[i-1]=p_restPlace;
	}
	else if(quaratineState==NO_QUARANTINE)//person feels fine, is in state, and will have their regular schedule
	{
		for(int i=1;i<=24;i++)//reset all schedule hours to resting place, people too sick to work will not be scheduled anywhere else
			_schedule[i-1]=p_restPlace;

		if (day%7 != 0 && day%7 != 6)  //a weekday begins ...
		{
				if(_age<=22)//person gets a child schedule
					setChildSchedule();
				else
					setAdultSchedule();
		}
		else//a weekend day begins ...
		{
			setWeekendSchedule();
		}
	}
}
void Person::setAdultSchedule()
{
	if(p_workplace->eType!=Business::HOME && _traveling==false)//person works outside the home and is not traveling
	{//send person to work from 8:00-17:00
		for(int hr=8;hr<=17;hr++)
			_schedule[hr-1]=p_workplace;
		//after work errands
		for(int hr=18;hr<=19;hr++)
		{
			float y=p_city->getSimRun()->uni(0,1);

			int low=0;
			int high=p_visitingCity->getBusinessSize()-1;
			int mid = (low + high)/2;
			while ( high - low >= 5) {
				if( y <= p_visitingCity->getBusiness(mid)->getPerWeekdayErrands() ){
					high = mid;
					mid = (low + high)/2;
				}
				if( y >p_visitingCity->getBusiness(mid)->getPerWeekdayErrands() ){
					low = mid;
					mid = (low + high)/2;
				}
			}
			// fish out y in the cum % of weekday errands in business entities
			for (int i = low; i <= high; i++) {
				float prevWeekErrPer=p_visitingCity->getBusiness(i-1)->getPerWeekdayErrands();
				if (y >= prevWeekErrPer && y < p_visitingCity->getBusiness(i)->getPerWeekdayErrands()) {
					_schedule[hr-1] = p_visitingCity->getBusiness(i);
				}
			}
		}
	}
	else //person is unemployed,traveling, or works at home
	{
		// select 3 different time slots between 8:00 and 19:00
		set<int> errandHours; //a set ensures each number hour will be a unique value
		while(errandHours.size()<3)
		{
			int hr=(int)p_city->getSimRun()->uni(8,20);
			errandHours.insert(hr); 
		}
		int slot=0;
		//set the errand hours
		for(set<int>::iterator it=errandHours.begin();it!=errandHours.end();it++)
		{
					_errandsUnemployed[slot]._numContacts=0;//clear yesterdays contacts
					_errandsUnemployed[slot]._errandHour=*it;
					slot++;
		}
		//put 2 contacts into the schedule
		for(int i=0;i<2;i++)
		{
			int slot=(int)p_city->getSimRun()->uni(0,3);
			_errandsUnemployed[slot]._numContacts++;
		}
		//set the business location of the errands and the daily schedule
		for (int err= 0; err<3 ;err++) {
			float y = p_city->getSimRun()->uni(0, 1);
			// fish out y in the cum % of weekday errands in business entities
            int low = 1; 
			int high = p_visitingCity->getBusinessSize()-1;
			int mid = (low + high)/2;
			while ( high - low >= 5) {
				if( y <= p_visitingCity->getBusiness(mid)->getPerWeekdayErrands() ){
					high = mid;
					mid = (low + high)/2;
				}
				if( y > p_visitingCity->getBusiness(mid)->getPerWeekdayErrands() ){
					low = mid;
					mid = (low + high)/2;
				}
			}
			for (int i = low; i <= high; i++) {
				float prevWeekErrPer=p_visitingCity->getBusiness(i-1)->getPerWeekdayErrands();
				if (y >= prevWeekErrPer && y < p_visitingCity->getBusiness(i)->getPerWeekdayErrands()) {
					_schedule[_errandsUnemployed[err]._errandHour-1] = p_visitingCity->getBusiness(i);
					_errandsUnemployed[err]._businessId=p_visitingCity->getBusiness(i)->getId(); //record the associated business
				}
			}
		}
	}
}
void Person::setChildSchedule()
{
	if(_traveling==true || _age <3)//child is out of town or too young for school, assign the child weekday errands
	{
		// select 3 different time slots between 8:00 and 19:00
		set<int> errandHours; //a set ensures each number hour will be a unique value
		while(errandHours.size()<3)
		{
			int hr=(int)p_city->getSimRun()->uni(8,20);
			errandHours.insert(hr); 
		}
		int slot=0;
		//set the errand hours
		for(set<int>::iterator it=errandHours.begin();it!=errandHours.end();it++)
		{
					_errandsUnemployed[slot]._numContacts=0;//clear yesterdays contacts
					_errandsUnemployed[slot]._errandHour=*it;
					slot++;
		}
		//put 2 contacts into the schedule
		for(int i=0;i<2;i++)
		{
			int slot=(int)p_city->getSimRun()->uni(0,3);
			_errandsUnemployed[slot]._numContacts++;
		}
		//set the business location of the errands and the daily schedule
		for (int err= 0; err<3 ;err++) {
			float y = p_city->getSimRun()->uni(0, 1);
			// fish out y in the cum % of weekday errands in business entities
            int low = 1; 
			int high = p_visitingCity->getBusinessSize()-1;
			int mid = (low + high)/2;
			while ( high - low >= 5) {
				if( y <= p_visitingCity->getBusiness(mid)->getPerWeekdayErrands() ){
					high = mid;
					mid = (low + high)/2;
				}
				if( y > p_visitingCity->getBusiness(mid)->getPerWeekdayErrands() ){
					low = mid;
					mid = (low + high)/2;
				}
			}
			for (int i = low; i <= high; i++) {
				float prevWeekErrPer=p_visitingCity->getBusiness(i-1)->getPerWeekdayErrands();
				if (y >= prevWeekErrPer && y < p_visitingCity->getBusiness(i)->getPerWeekdayErrands()) {
					_schedule[_errandsUnemployed[err]._errandHour-1] = p_visitingCity->getBusiness(i);
					_errandsUnemployed[err]._businessId=p_visitingCity->getBusiness(i)->getId(); //record the associated business
				}
			}
		}
	}
	else 
	{
	// send the child to his school from 8:00 to 15:00
		for (int hr = 8; hr <= 15; hr++) 
			_schedule[hr-1]=p_workplace;

	// look for the afterschool center
		int center = (int)p_city->getSimRun()->uni(0,p_city->getBusinessNumbers(9));
		for (int i = 1; i <= p_city->getBusinessSize(); ++i)
		{
			if(p_city->getBusiness(i)->eType==Business::AFTERSCHOOL_CENTER)
			{	// put the afterschool center on the child's schedule
				for(int hr=16; hr<=19;hr++)
				{
					_schedule[hr-1]=p_city->getBusiness(i+center);
				}	
				break;
			}
		}
	}
}
void Person::setWeekendSchedule()
{
	// select 3 different time slots between 10:00 and 20:00
	set<int> errandHours; //a set ensures each number hour will be a unique value
	while(errandHours.size()<3)
	{
		int hr=(int)p_city->getSimRun()->uni(10,21);
		errandHours.insert(hr); 
	}
	int slot=0;
	//set the errand hours
	for(set<int>::iterator it=errandHours.begin();it!=errandHours.end();it++)
	{
		_errandsWeekend[slot]._numContacts=0;//clear yesterdays contacts
		_errandsWeekend[slot]._errandHour=*it;
		slot++;
	}
	//put 2 contacts into the schedule
	for(int i=0;i<2;i++)
	{
		int slot=(int)p_city->getSimRun()->uni(0,3);
		_errandsWeekend[slot]._numContacts++;
	}
	//set the business location of the errands and the daily schedule
	for (int err= 0; err<3 ;err++) {
		float y = p_city->getSimRun()->uni(0, 1);
		// fish out y in the cum % of weekday errands in business entities
        int low = 1; 
		int high = p_visitingCity->getBusinessSize()-1;
		int mid = (low + high)/2;
		while ( high - low >= 5) {
			if( y <= p_visitingCity->getBusiness(mid)->getPerWeekendErrands() ){
				high = mid;
				mid = (low + high)/2;
		}
			if( y > p_visitingCity->getBusiness(mid)->getPerWeekendErrands() ){
				low = mid;
				mid = (low + high)/2;
			}
		}
		for (int i = low; i <= high; i++) {
			float prevWeekErrPer=p_visitingCity->getBusiness(i-1)->getPerWeekendErrands();
			if (y >= prevWeekErrPer && y < p_visitingCity->getBusiness(i)->getPerWeekendErrands()) {
				_schedule[_errandsWeekend[err]._errandHour-1] = p_visitingCity->getBusiness(i);
				_errandsWeekend[err]._businessId=p_visitingCity->getBusiness(i)->getId(); //record the associated business
			}
		}
	}
}
//adds the person to the list of occupants at his/her location at the hour passed as an argument
void Person::declareLocation(int hr)
{
	if(quaratineState!=HOSPITALIZED && p_restPlace !=p_Outside)// hospital and out of state locations are null pointers
	{
		if(!_schedule[hr-1]->hasOccupant(this))
			_schedule[hr-1]->addOccupant(this);
	}
}

void Person::processInfections(int hr, int day)
{
	if((_disease_clock_pandemic>0 && _disease_clock_pandemic<culmination_period)||(_disease_clock_seasonal>0 && _disease_clock_seasonal<culmination_period))
	{
			
			if(quaratineState!=HOSPITALIZED && p_restPlace !=p_Outside)//person is in state, out of the Hospital and can make contacts
			{
				float locMod=Flu_Manager::Instance()->k_hh;//currentlocationModifier
				std::vector<int> checkHours;//the key hours of the day to accumulate contacts
				if(day%7!=0 && day%7 !=6)//weekday
				{
					if(hr==20)//everyone goes home at this time
					{
						_contactCounterHH=makeContacts(hr,locMod,WEEKDAY,0);
						p_visitingCity->total_HH +=_contactCounterHH;
						infectContacts(day);//at the end of the day all contacts are made, time to infect them
					}		
					else if(p_workplace->eType!=Business::HOME && quaratineState==NO_QUARANTINE && _traveling==false)
					{

						if(hr==8)
						{
							locMod=Flu_Manager::Instance()->k_wp;
							_contactCounterWP=makeContacts(hr,locMod,WEEKDAY,0);
							p_city->total_WP +=_contactCounterWP;
						}	
						else if(_age>22 && hr==18)//adult
						{
							locMod=Flu_Manager::Instance()->k_er;
							_contactCounterER=makeContacts(hr,locMod,WEEKDAY,0);
							p_city->total_ER +=_contactCounterER;
						}
						else if(_age<=22 && hr==16)//child
						{
							locMod=Flu_Manager::Instance()->k_er;
							_contactCounterER=makeContacts(hr,locMod,WEEKDAY,0);
							p_city->total_ER +=_contactCounterER;
						}
					}
					else if(quaratineState==NO_QUARANTINE )//unemployed or traveling
					{
						for(int err=0;err<3;err++)
						{
							if(_errandsUnemployed[err]._errandHour==hr)
							{
								locMod=Flu_Manager::Instance()->k_er;
								_contactCounterER+=makeContacts(hr,locMod,UNEMPLOYED,err);
								p_visitingCity->total_ER +=_contactCounterER;
							}
						}
					}
				}
				else//weekend
				{
					if(hr==21)//everyone goes home at this time
					{
						_contactCounterHH=makeContacts(hr,locMod,0,0);
						p_visitingCity->total_HH +=_contactCounterHH;
						infectContacts(day);//at the end of the day all contacts are made, time to infect them
					}
					else if(quaratineState==NO_QUARANTINE)
					{
						for(int err=0;err<3;err++)
						{
							if(_errandsWeekend[err]._errandHour==hr)
							{
								locMod=Flu_Manager::Instance()->k_er;
								_contactCounterER+=makeContacts(hr,locMod,WEEKEND,err);
								p_visitingCity->total_ER +=_contactCounterER;
							}
						}
					}	
				}
			}
	}
}
//sets the disease profile of newly infected individuals
void Person::profile_assignment(eVirusMode virusType)
{
    if(Flu_Manager::Instance()->currentStrain==Flu_Manager::VirusStrain::H3N2)
    {
        if (p_city->getSimRun()->uni(0,1)<=PERCENT_SYMPTOMATIC)
            symptomatic = SYMPTOMATIC;
        else
            symptomatic = ASYMPTOMATIC;
        profilePandemic=H3N2;
        profileSeasonal=H3N2;
    }
    else
    {
        int prof;
        switch(virusType)
        {
            case PANDEMIC:
            {
                if (p_city->getSimRun()->uni(0,1)<=PERCENT_SYMPTOMATIC){
                    symptomatic = SYMPTOMATIC;
                    prof=(int)ceil(p_city->getSimRun()->uni(0,3));
                }
                else
                {
                    symptomatic = ASYMPTOMATIC;
                    prof=(int)ceil(p_city->getSimRun()->uni(3,6));
                }
                profilePandemic= (eProfileType)prof;
                break;
            }
            case SEASONAL:
            {
                if (p_city->getSimRun()->uni(0,1)<=PERCENT_SYMPTOMATIC){
                    symptomatic = SYMPTOMATIC;
                    prof=(int)ceil(p_city->getSimRun()->uni(0,3));
                }
                else
                {
                    symptomatic = ASYMPTOMATIC;
                    prof=(int)ceil(p_city->getSimRun()->uni(3,6));
                }
                profileSeasonal= (eProfileType)prof;
                break;
            }
            case BOTH:
            {
                if (p_city->getSimRun()->uni(0,1)<=PERCENT_SYMPTOMATIC){
                    symptomatic = SYMPTOMATIC;
                    prof=(int)ceil(p_city->getSimRun()->uni(0,3));
                }
                else
                {
                    symptomatic = ASYMPTOMATIC;
                    prof=(int)ceil(p_city->getSimRun()->uni(3,6));
                }
                profilePandemic= (eProfileType)prof;
                if(symptomatic==ASYMPTOMATIC)
                {
                        if (p_city->getSimRun()->uni(0,1)<=PERCENT_SYMPTOMATIC){
                            symptomatic = SYMPTOMATIC;
                            prof=(int)ceil(p_city->getSimRun()->uni(0,3));
                        }
                        else
                            prof=(int)ceil(p_city->getSimRun()->uni(3,6));
                }
                else
                        prof=(int)ceil(p_city->getSimRun()->uni(0,3));
                profileSeasonal= (eProfileType)prof;
                break;
            }
        }
    }
}

int Person::makeContacts(int hr,float locMod,int scheduleType,int errandHour)
{
	unsigned int cr;
	if(scheduleType==UNEMPLOYED)//unemployed and on an errand
		cr=_errandsUnemployed[errandHour]._numContacts;
	else if(scheduleType==WEEKEND)//on a weekend errand
		cr=_errandsWeekend[errandHour]._numContacts;
	else//at work or home
		cr=(unsigned int)_schedule[hr-1]->getContactRate();//maximum number of contacts
	if(_schedule[hr-1]->getOccupants().size()<=cr)//can't have more contacts than people present -infector
			cr=_schedule[hr-1]->getOccupants().size()-1;
	if (cr > 0)//infector does not work/live alone
	{	
		int ct=0;
		while(ct < cr)
		{
			int found=0;
			while(found==0)
			{
				int randContact=(int)p_city->getSimRun()->uni(0,_schedule[hr-1]->getOccupants().size());
				if(_id !=_schedule[hr-1]->getOccupants().at(randContact)->getId())//make sure contact isn't infector
				{	
					struct Contact contact;
					contact._contactee=_schedule[hr-1]->getOccupants().at(randContact);
					contact._locModifier=locMod;
					found=1;
					ct++;
					_contacts.push_back(contact);
					//int id=contact._contactee->getId();
					//fprintf(p_visitingCity->checkContacts,"person %d contacted person %d\n",_id,id);
				}
			}
		}
	}
	return cr;
}

bool Person::checkIds(int id, std::vector<int>& used)
{
	if(!used.empty())
	{
		for(unsigned int i=0;i<used.size();i++)
		{
			if(id==used[i])
				return false;
		}
	}	
	return true;
}

void Person::infectContacts(int day)
{
	//loop through contacts and try to infect them
	for(unsigned int i=0;i<_contacts.size();i++)
        exposeContact(_contacts[i]._contactee,_contacts[i]._locModifier,day);
		
	//clear contact list for the next day
	_contacts.clear();
	_contactCounterHH=0;
	_contactCounterWP=0;
	_contactCounterER=0;
}
//A contact is exposed to a virus. If the probability of infection is met, the person is infected.
void Person::exposeContact(Person* contactee,float locationModifier,int day)
{
	float prob=0.0f;//probability of catching a virus
	float diceRoll=p_city->getSimRun()->uni(0,1);//compared to probability

	switch(currentVirusType)
	{
		case BOTH: //contactor can transmit either or both viruses
		{
			bool infected=false;
			float prob_p=0.0f;
			float prob_s=0.0f;
			if(contactee->prevVirusType!=PANDEMIC && contactee->prevVirusType!=BOTH)//pesron has no prev infection with pandemic virus
			{
				if(_daysOfPandemicInfection>=0)
				{
					float diceRoll=p_city->getSimRun()->uni(0,1);//compared to probability
                    prob_p=setProbability(_rn_init_pandemic,profilePandemic,_daysOfPandemicInfection,true,contactee,locationModifier);
					if(diceRoll<=prob_p)
					{
						contactee->infected(true,this,day);
						infected=true;
					}		
				}
			}
			if(contactee->prevVirusType!=SEASONAL && contactee->prevVirusType!=BOTH )//person has no previous infection with seasonal virus
			{
				if(_daysOfSeasonalInfection>=0)
				{
					float diceRoll=p_city->getSimRun()->uni(0,1);//compared to probability
                    prob_s=setProbability(_rn_init_seasonal,profileSeasonal,_daysOfSeasonalInfection,false,contactee,locationModifier);
					if(diceRoll<=prob_s)
					{
						contactee->infected(false,this,day);
						infected=true;
					}		
				}
			}
			if(infected==true && p_home !=nullptr) //dont include infected out of state arrivals
				contactee->getCity()->addInfected(contactee);		
			break;
		}
		case PANDEMIC://contactor can transmit pandemic virus
		{
			if(contactee->prevVirusType!=PANDEMIC && contactee->prevVirusType!=BOTH)//person has no prev infection with pandemic virus
			{
				if(_daysOfPandemicInfection>=0)
				{
                    prob=setProbability(_rn_init_pandemic,profilePandemic,_daysOfPandemicInfection,true,contactee,locationModifier);//current probability to be used
					if(diceRoll<=prob)
					{
						contactee->infected(true,this,day);
						if(p_home !=nullptr)//dont include infected out of state arrivals
							contactee->getCity()->addInfected(contactee);				
					}
				}
			}	
			break;
		}
		case SEASONAL://contactor can transmit seasonal virus
		{
			if(contactee->prevVirusType!=SEASONAL && contactee->prevVirusType!=BOTH)//person has no previous infection with seasonal virus
			{
				if(_daysOfSeasonalInfection>=0)
				{
                    prob=setProbability(_rn_init_seasonal,profileSeasonal,_daysOfSeasonalInfection,false,contactee,locationModifier);
					if(diceRoll<=prob)
					{
						contactee->infected(false,this,day);
						if(p_home !=nullptr)//dont include infected out of state arrivals
							contactee->getCity()->addInfected(contactee);				
					}
				}
			}
			break;
		}
	}
}
//Determine the probabilit of a person being infected based on the reproduction number(reproNUm), disease profile(profile), and number of days infected(daysInfected)
float Person::setProbability(float reproNum,eProfileType profile, int daysInfected, bool pandemic, Person* contactee,float locMod)
{
	float vaccineFactor=1.0f;//factor by which probability of infection is reduced due to vaccination of infector, 1 = not vaccinated
	float vaccineOther=1.0f;//factor by which probability of infection is reduced due to vaccination of contact, 1 = not vaccinated
	float antiviralFactor=1.0f;//factor by which probability of infection is reduced due to antiviral treatment of the infector, 1= not given antivirals
	float antiviralOther=1.0f;//factor by which probability of infection is reduced due to antiviral treatment of the contact, 1= not given antivirals
	bool vaccinated;//is the infector vaccinated
	bool vaccinatedOther;//is the contactee vaccinated
	//assign the above bools to the appropriate virus type
	if(pandemic==true)
	{
		vaccinated=_vaccinated_pandemic;
		vaccinatedOther=contactee->getVaccinationStatusPandemic();
	}
	else
	{
		vaccinated=_vaccinated_seasonal;
		vaccinatedOther=contactee->getVaccinationStatusSeasonal();
	}
	if(vaccinated==true)
	{	//vaccinating the infector reduces the infectiousness of the virus
		vaccineFactor=Flu_Manager::Instance()->Flu_Manager::Instance()->VACCINE_COEFF_INFECTIOUSNESS;
		if(symptomatic == SYMPTOMATIC)//additional reduction occurs when the infector is symptomatic
			vaccineFactor*=Flu_Manager::Instance()->VACCINE_COEFF_SYMPTOMATIC;
	}
	if(vaccinatedOther==true)//vaccinating the contactee reduces the likelyhood of transmission of virus
		vaccineOther=Flu_Manager::Instance()->VACCINE_COEFF_TRANSMISSION;
	if(_onAntivirals==true)
	{
		antiviralFactor = Flu_Manager::Instance()->AV_INFECTIOUSNESS;
		if(symptomatic == SYMPTOMATIC)
			antiviralFactor *= Flu_Manager::Instance()->AV_SYMPTOMATIC;
	}
	if(contactee->getAntiviralStatus()==true)
		antiviralOther=Flu_Manager::Instance()->AV_TRANSMISSION;
	float profileType,prob;
	switch(profile)
	{
	case GAMMA_1:
		{
			profileType=Flu_Manager::Instance()->getGamma1CumDensity(daysInfected);
			break;
		}
	case LOGNORMAL_1:
		{
			profileType=Flu_Manager::Instance()->getLognormal1CumDensity(daysInfected);
			break;
		}
	case WEIBULL_1:
		{
			profileType=Flu_Manager::Instance()->getWeibu1CumDensity(daysInfected);
			break;		
		}
	case GAMMA_2:
		{
			profileType=Flu_Manager::Instance()->getGamma2CumDensity(daysInfected);
			break;
		}
	case LOGNORMAL_2:
		{
			profileType=Flu_Manager::Instance()->getLognormal2CumDensity(daysInfected);
			break;
		}
	case WEIBULL_2:
		{
			profileType=Flu_Manager::Instance()->getWeibu2CumDensity(daysInfected);
			break;
		}
    case H3N2:
        {
            profileType=Flu_Manager::Instance()->getH3n2CumDensity(daysInfected);
            break;
        }
	}
    if(symptomatic==SYMPTOMATIC)//a symptomatic probability
		prob=((reproNum/(((1-Flu_Manager::Instance()->asymp)*PERCENT_SYMPTOMATIC)+Flu_Manager::Instance()->asymp))*profileType)/((_contactCounterHH*Flu_Manager::Instance()->k_hh)+(_contactCounterWP*Flu_Manager::Instance()->k_wp)+(_contactCounterER*Flu_Manager::Instance()->k_er));	
    else//an asymptomatic probability
		prob=(Flu_Manager::Instance()->asymp*(reproNum/(((1-Flu_Manager::Instance()->asymp)*PERCENT_SYMPTOMATIC)+Flu_Manager::Instance()->asymp))*profileType)/((_contactCounterHH*Flu_Manager::Instance()->k_hh)+(_contactCounterWP*Flu_Manager::Instance()->k_wp)+(_contactCounterER*Flu_Manager::Instance()->k_er));
	prob*=vaccineFactor*vaccineOther*antiviralFactor*antiviralOther*locMod;//probability reduced if vaccinated or on antivirals
	return prob;
}
/*Check if travelers should return home and which infected individuals will travel*/
void Person::setTravelState()
{
	//check who will be traveling
	if(_traveling==false)
	{
		float diceRoll=p_city->getSimRun()->uni(0,1);
		if(Flu_Manager::Instance()->ALLOW_TRAVEL==0)//only out of state travel being used
		{
			if(diceRoll<=p_city->getProbTravel()*.411f)
			{
				p_restPlace=p_Outside;
				p_visitingCity=p_city;
				_traveling =true;
			}
		}
		else
		{
			if(diceRoll<=p_city->getProbTravel())//person is traveling
			{
				_traveling =true;
				//create a list of destination regions and a matching list of cumulative probabilites
				std::vector<float> cumDestProb;
				std::vector<City*> destCities;
				float sumOfprob=0.0f;
				//populate the lists
				for(int i=0;i<Flu_Manager::Instance()->NUM_CITIES;i++)
				{
					if(i != p_city->getId())//not the home region
					{
						destCities.push_back(p_city->getSimRun()->getCity(i));
						float prob=p_city->getSimRun()->getCity(i)->getProbDestination();
						cumDestProb.push_back(sumOfprob+prob);//make each prob cumulative with the previous
						sumOfprob+=prob;		
					}	
				}
				//if there is no out of state travel, normalize the cumulative probabilities of regional travel
				if(Flu_Manager::Instance()->ALLOW_OOS_TRAVEL==0)
				{
					for(unsigned int i=0;i<cumDestProb.size();i++)
					{
						cumDestProb[i]=cumDestProb[i]/cumDestProb[cumDestProb.size()-1];
					}
				}
				//find the destination
				diceRoll=p_city->getSimRun()->uni(0,1);
				for(unsigned int i=0;i<cumDestProb.size();i++)
				{
					if(diceRoll<=cumDestProb[i])
					{
						p_visitingCity=destCities[i];
						break;
					}
				}
				if(diceRoll>cumDestProb[cumDestProb.size()-1])//person is leaving the state
				{
					p_restPlace=p_Outside;
					p_visitingCity=p_city;
				}
				if(p_visitingCity !=p_city)//person is traveling within state
				{
					//start the destinations outbreak if it has not already been started
					if(p_visitingCity->getDaysOutbreak()<=0)
					p_visitingCity->startOutbreak();
					//where is traveler staying
					pickRestingPlace();
				}
			}
			//how long will the traveler stay?
			int longestPossible=0;//longest period traveler will be gone = days left of disease
			if(_daysOfPandemicInfection < _daysOfSeasonalInfection && _daysOfPandemicInfection>=0)
				longestPossible=10-_daysOfPandemicInfection;
			else
				longestPossible=10-_daysOfSeasonalInfection;
			if(longestPossible >1)
				_maxTravelDays=(int)p_city->getSimRun()->uni(1,longestPossible);
			else
				_maxTravelDays=1;
			/*is this a family trip?
			float probFamilyTrip=.25f;
			diceRoll=Flu_Manager::Instance()->uni(0,1);
			if(diceRoll<=probFamilyTrip)
			{
				//add the other adults in the household
				for(int i=0;i < p_home->getNumAdults();i++)
				{
					if(p_home->getAdult(i)->getId()!=_id)
						p_home->getAdult(i)->setTraveling(p_visitingCity,p_restPlace,_maxTravelDays);
				}
				if(p_home->getNumChildren()>0)//add kids to travelers
				{
					for(int i=0;i < p_home->getNumChildren();i++)
					{
						if(p_home->getChild(i)->getAge()<18)
							p_home->getChild(i)->setTraveling(p_visitingCity,p_restPlace,_maxTravelDays);
					}
				}
			}*/
		}
	}
	else //check how long travelers have been away, if = max travel days end travel for them
	{
		if(_daysTraveled>=_maxTravelDays)//done with trip
		{
			stopTraveling();
		}
		else//add a day of travel
			_daysTraveled++;
	}	
}
//set a person as a traveler
/*void Person::setTraveling(City* city,Location* loc,int daysGone)
{
	_traveling=true;
	p_visitingCity=city;
	p_restPlace=loc;
	_maxTravelDays=daysGone;
}*/

void Person::stopTraveling()
{
	_traveling = false;
	p_visitingCity=p_city;
	p_restPlace=p_home;
	_maxTravelDays=0;
	_daysTraveled =0;
}

void Person::pickRestingPlace()
{
	//where is traveler staying
	float probHouse=.5f;//as a coin toss due no available data on where travelers stay
	float diceRoll=p_city->getSimRun()->uni(0,1);
	if(diceRoll<=probHouse)
	{
		//pick a houshold at random
		int randomHouseId=(int)p_city->getSimRun()->uni(0,p_visitingCity->getNumHouseholds());
		p_restPlace=p_visitingCity->getHousehold(randomHouseId);
	}
	else
	{
		//pick an entertainment business at random
		int randHotel=(int)p_city->getSimRun()->uni(0,p_visitingCity->getBusinessNumbers(13));
		for (int i = 1; i <= p_visitingCity->getBusinessSize(); ++i)
		{
			if(p_visitingCity->getBusiness(i)->eType==Business::ENTERTAINMENT)
			{
				p_restPlace=p_visitingCity->getBusiness(i+randHotel);
				break;
			}
		}
	}
}

void Person::setArrivalSchedule(int day)
{
	for(int i=1;i<=24;i++)
		_schedule[i-1]=p_restPlace;
	if(day % 7==0 || day % 7==6) //weekend
		setWeekendSchedule();
	else
	{	// select 3 different time slots between 8:00 and 19:00
		set<int> errandHours; //a set ensures each number hour will be a unique value
		while(errandHours.size()<3)
		{
			int hr=(int)p_city->getSimRun()->uni(8,20);
			errandHours.insert(hr); 
		}
		int slot=0;
		//set the errand hours
		for(set<int>::iterator it=errandHours.begin();it!=errandHours.end();it++)
		{
					_errandsUnemployed[slot]._numContacts=0;//clear yesterdays contacts
					_errandsUnemployed[slot]._errandHour=*it;
					slot++;
		}
		//put 2 contacts into the schedule
		for(int i=0;i<2;i++)
		{
			int slot=(int)p_city->getSimRun()->uni(0,3);
			_errandsUnemployed[slot]._numContacts++;
		}
		//set the business location of the errands and the daily schedule
		for (int err= 0; err<3 ;err++) {
			float y = p_city->getSimRun()->uni(0, 1);
			// fish out y in the cum % of weekday errands in business entities
            int low = 1; 
			int high = p_city->getBusinessSize()-1;
			int mid = (low + high)/2;
			while ( high - low >= 5) {
				if( y <= p_city->getBusiness(mid)->getPerWeekdayErrands() ){
					high = mid;
					mid = (low + high)/2;
				}
				if( y > p_city->getBusiness(mid)->getPerWeekdayErrands() ){
					low = mid;
					mid = (low + high)/2;
				}
			}
			for (int i = low; i <= high; i++) {
				float prevWeekErrPer=p_city->getBusiness(i-1)->getPerWeekdayErrands();
				if (y >= prevWeekErrPer && y < p_city->getBusiness(i)->getPerWeekdayErrands()) {
					_schedule[_errandsUnemployed[err]._errandHour-1] = p_city->getBusiness(i);
					_errandsUnemployed[err]._businessId=p_city->getBusiness(i)->getId(); //record the associated business
				}
			}
		}
	}
}

void Person::setTraveling(bool travel)
{
	_traveling=travel;
}
