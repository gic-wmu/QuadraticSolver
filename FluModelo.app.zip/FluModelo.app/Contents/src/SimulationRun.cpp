/*
 *  This file is part of Flu Modelo
 *
 *  Copyright (C) Western Michigan University

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

    authors-Greg Ostroy, Diana Prieto, Yuwen Gu
*/

#include <string>
#include <string.h>
#include <stdio.h>
#include "SimulationRun.h"
#include "Flu_Manager.h"


SimulationRun::SimulationRun(int id, MainWindow * window)
{
    _window=window;
	_id=id;
	_uniform_counter = 1;
	_seed=Flu_Manager::Instance()->SEED +_id;
	_totalPopulation=0;
	total_infected_pandemic = 0;
	total_infected_seasonal = 0;
	total_sim_coinfected = 0;
	total_infected_pandemic_only = 0;
	total_infected_seasonal_only = 0;
	total_coinfected_s_p = 0;
	total_reinfected_s_p = 0;
	total_coinfected_p_s = 0;
	total_reinfected_p_s = 0;

	new_infected_today_pandemic = 0; // number of new infected entities every day
	new_infected_today_seasonal = 0; // number of new infected entities every day
	new_infected_today_pandemic_only = 0; // number of new infected entities every day
	new_infected_today_seasonal_only = 0; // number of new infected entities every day
	new_sim_coinfected = 0; // number of new infected entities every day
	new_coinfected_s_p = 0; // number of new infected entities every day
	new_reinfected_s_p = 0; // number of new infected entities every day
	new_coinfected_p_s = 0; // number of new infected entities every day
	new_reinfected_p_s = 0; // number of new infected entities every day
	new_recovered_today_pandemic = 0; // number of new recovered entities every day
	new_recovered_today_seasonal = 0; // number of new recovered entities every day
	//create an array of uniform random numbers
	for (int i = 1; i <= 10000; ++i) 
	{
		_uniform[i]= (float)fluRandom();
	}
	//generate cities
	for(int i=0;i<Flu_Manager::Instance()->NUM_CITIES;i++)
	{
		City* city;
		if(i==0)//outbreak starts in this city
			city =new City(i,true,this);
		else
			city =new City(i,false,this);
		_cities.push_back(city);
		_totalPopulation+=city->getPopulationSize();
        QString str =QString("city %1 for run %2 generated").arg(city->getId()).arg(_id);
        _window->updateStatus(str);
	}
}

SimulationRun::~SimulationRun()
{

	for(unsigned int i=0;i<_cities.size();i++)
	{
		delete _cities[i];
		_cities[i]=nullptr;
	}
}

int SimulationRun::getId() const
{
	return _id;
}

City* SimulationRun::getCity(int index) const
{
	return _cities[index];
}

void SimulationRun::outbreak()
{
	int		t_now = 0; // simulation clock time in hours
	int day;//days of simulation
	int hr;// hour of a given day
	//generate unique name for run output
	char runId[3];
	sprintf(runId,"%d",_id);//convert id to string
	std::string RunStr="Run_no";
	RunStr+=runId;
	char statStr[34];
	strcpy(statStr,RunStr.c_str());
	char baseStr[26]="_output_general_stats.txt";
	strcat(statStr,baseStr);

	FILE* globalOutput_genStats=fopen(statStr,"w");
	fprintf(globalOutput_genStats, "Day  Population  Infected_total  Infected_p  Recovered_p  Infected_s  Recovered_s  Infected_p_only  Infected_s_only coinfected_s_p reinfected_s_p coinfected_p_s reinfected_p_s coinfected_sim\n");
	for(unsigned int i=0;i<_cities.size();i++)
		_cities[i]->openOutputFiles();
    while(hasCityWithOutbreak()&&_window->currentState==MainWindow::RUNNING)
	{
		day = 1+t_now/24; // A day begins ...
		if (day >=2){//hr cycles from 1 to 24
			hr=(t_now-(24*(day-1)))+1; 
		}
		else {//less than 24 hours have passed
			hr=t_now+1;            
		}
        QString str=QString("Run %1 Day %2  Hour %3").arg(_id).arg(day).arg(hr);
         _window->updateStatus(str);
		//have each city updates its flu outbreak
		for(unsigned int i=0;i<_cities.size();i++)
		{
            if(_cities[i]->outbreakRunning()&& _window->currentState==MainWindow::RUNNING)
			{
				_cities[i]->updateOutbreak(hr,day);
				if(hr==23)//time to collect infection data
				{
					new_recovered_today_pandemic+=_cities[i]->getNewRecoverd(true);
					new_recovered_today_seasonal+=_cities[i]->getNewRecoverd(false);
					total_sim_coinfected += _cities[i]->getNewInfectedByType(COINFECTED_SIMULTANEOUS);
		 			total_infected_pandemic_only += _cities[i]->getNewInfectedByType(INFECTED_PANDEMIC);
		 			total_infected_seasonal_only += _cities[i]->getNewInfectedByType(INFECTED_SEASONAL);
		 			total_coinfected_s_p += _cities[i]->getNewInfectedByType(COINFECTED_SEASONAL_PANDEMIC);
		 			total_reinfected_s_p +=_cities[i]->getNewInfectedByType(REINFECTED_SEASONAL_PANDEMIC);
		 			total_coinfected_p_s += _cities[i]->getNewInfectedByType(COINFECTED_PANDEMIC_SEASONAL);
					total_reinfected_p_s += _cities[i]->getNewInfectedByType(REINFECTED_PANDEMIC_SEASONAL);
					total_infected_pandemic = total_infected_pandemic_only+total_coinfected_s_p +total_reinfected_s_p +total_sim_coinfected;
		 			total_infected_seasonal = total_infected_seasonal_only+total_coinfected_p_s+total_reinfected_p_s+ total_sim_coinfected;
					total_infected=total_infected_pandemic_only+total_infected_seasonal_only+total_sim_coinfected;
				}
			}
		}
		if(hr==24)
		{
			_infectedByDay_p.push_back(total_infected_pandemic);
			_infectedByDay_s.push_back(total_infected_seasonal);
			_totalInfectedByDay.push_back(total_infected);

			fprintf( globalOutput_genStats,"%d		%d		%d		%d		%d		%d		%d		%d		%d		%d		%d		%d		%d		%d \n",day,_totalPopulation,total_infected,total_infected_pandemic,new_recovered_today_pandemic,total_infected_seasonal,new_recovered_today_seasonal,total_infected_pandemic_only,total_infected_seasonal_only,total_coinfected_s_p,total_reinfected_s_p,total_coinfected_p_s,total_reinfected_p_s,total_sim_coinfected);
			//reset global daily variables
			new_recovered_today_pandemic = 0;
			new_recovered_today_seasonal = 0;
		}
		t_now++;
	}
	fclose(globalOutput_genStats);
	for(unsigned int i=0;i<_cities.size();i++)
	{
		_cities[i]->closeOutputFiles();
		_cities[i]->checkRNumber();	
	}
	//print the rn totals
	char rnStr[21];
	strcpy(rnStr,RunStr.c_str());
	strcat(rnStr,"output_R.txt");

    //set days to record data, in case the simulation was not run for the number of days set
    int recordDays=0;
    if(day < Flu_Manager::Instance()->max_days)//simulation was cut short
            recordDays=day;
    else
            recordDays=Flu_Manager::Instance()->max_days;
	FILE* R_output= fopen(rnStr,"w");
	fprintf(R_output, "Generation   Generation_size_p   Avg_R_p   Generation_size_s   Avg_R_s   \n");
    for(int i=0; i< recordDays;i++)
	{
		float ave_rn_p=0.0f;//ave gen i+1 pandemic reproduction number for all cities
		float ave_rn_s=0.0f;//ave gen i+1 seasonal reproduction number for all cities
		float sum_rn_p=0.0f;//sum of cicties pandemic rn number for gen i+1
		float sum_rn_s=0.0f;//sum of cicties seasonal rn number for gen i+1
		int sumPandemicGeneration=0;//the sum of all the cities pandemic generations i+1
		int sumSeasonalGeneration=0;//the sum of all the cities seasonal generations i+1
		int sumCities_p=0;//the sum of all cities with a pandemic rn number for this generation >0
        int sumCities_s=0;//the sum of all cities with a seasonal rn number for this generation >0
		for(int c=0;c<Flu_Manager::Instance()->NUM_CITIES;c++)
		{
			if(_cities[c]->getPandemicRn(i)>0)
			{
				sum_rn_p+=_cities[c]->getPandemicRn(i);
				sumCities_p++;
			}	
			if(_cities[c]->getSeasonalRn(i)>0)
			{
				sum_rn_s+=_cities[c]->getSeasonalRn(i);
				sumCities_s++;
			}	
			sumPandemicGeneration +=_cities[c]->getPandemicGenerations(i);
			sumSeasonalGeneration +=_cities[c]->getSeasonalGenerations(i);
		}
		ave_rn_p=sum_rn_p/sumCities_p;
		ave_rn_s=sum_rn_s/sumCities_s;
		fprintf(R_output,"%d			%d				%f			%d				%f\n",i+1,sumPandemicGeneration,ave_rn_p,sumSeasonalGeneration,ave_rn_s);
	}
	fclose(R_output);
}

bool SimulationRun::hasCityWithOutbreak()
{
	for(unsigned int i=0;i<_cities.size();i++)
	{
			if(_cities[i]->outbreakRunning())
				return true;
	}
	return false;
}

int SimulationRun::getDailyInfectedPandemic(int index)
{
	return _infectedByDay_p[index];
}
int SimulationRun::getDailyInfectedSeasonal(int index)
{
	return _infectedByDay_s[index];
}
int SimulationRun::getTotalInfected(int index)
{
	return _totalInfectedByDay[index];
}
//return a random value between int a and int b
float SimulationRun::uni(int a, int b)
{
	if (_uniform_counter < 9999) {
		++_uniform_counter;
		return a + (b-a)*_uniform[_uniform_counter];
	}
	else {
		_uniform_counter = 1;
		return a + (b-a)*_uniform[_uniform_counter];
	}
}
//  creates iid random variates uniformly distributed between 0 and 1, based on a seed input from init files
double SimulationRun::fluRandom()
{
		long i=_seed/127773;
		long j=_seed%127773;
		long k=j*16807-i*2836;
		if (k>0) _seed=k;
		else _seed=k+2147483647;

		return _seed/2147483647.0;
}

float SimulationRun::getUniformValue(int index) 
{
	return _uniform[index];
}
