/*
 *  This file is part of Flu Modelo
 *
 *  Copyright (C) Western Michigan University

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

    authors-Greg Ostroy, Diana Prieto, Yuwen Gu
*/

#ifndef SAVEDIALOG_H
#define SAVEDIALOG_H

#include <QDialog>
#include "mainwindow.h"

namespace Ui {
class SaveDialog;
}

class SaveDialog : public QDialog
{
    Q_OBJECT

public:
    explicit SaveDialog(QWidget *parent = 0, MainWindow *win = 0);
    ~SaveDialog();

private slots:
    void on_saveButton_2_clicked();

    void on_saveButton_1_clicked();

    void on_saveButton_3_clicked();

private:
    MainWindow* _window;
    Ui::SaveDialog *ui;
    QString setDefaultString(int);
    void saveResult(QString,int);
};

#endif // SAVEDIALOG_H
